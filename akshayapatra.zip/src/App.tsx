import React, { useState } from 'react';
import { Donation, AppNotification, LeaderboardItem, Volunteer, UserRole } from './types';
import { 
  initialDonations, 
  initialVolunteers, 
  initialNotifications, 
  initialLeaderboard 
} from './data/mockData';
import { RoleSelector } from './components/RoleSelector';
import { WebView } from './components/WebView';
import { MobileView } from './components/MobileView';
import { NotificationCenter } from './components/NotificationCenter';
import { Sparkles, Monitor, Smartphone, RefreshCw, Layers, Brain, Award } from 'lucide-react';

export default function App() {
  // Shared state acting as our live cloud-synchronized Firebase instance
  const [donations, setDonations] = useState<Donation[]>(initialDonations);
  const [volunteers, setVolunteers] = useState<Volunteer[]>(initialVolunteers);
  const [notifications, setNotifications] = useState<AppNotification[]>(initialNotifications);
  const [leaderboard, setLeaderboard] = useState<LeaderboardItem[]>(initialLeaderboard);
  
  // App view controls
  const [platformView, setPlatformView] = useState<'web' | 'mobile'>('web');
  const [currentUser, setCurrentUser] = useState<{
    name: string;
    role: UserRole;
    email: string;
    orgName: string;
    phone: string;
  } | null>(null);

  // Floating notifications tray toggle
  const [showNotificationCenter, setShowNotificationCenter] = useState(false);

  // LOGOUT HANDLER
  const handleLogout = () => {
    setCurrentUser(null);
    setShowNotificationCenter(false);
  };

  // ADD NEW DONATION METHOD (Shared state addition)
  const handleAddDonation = (newDonationData: Omit<Donation, 'id' | 'createdAt' | 'restaurantName' | 'ngoName' | 'volunteerName' | 'volunteerPhone' | 'assignedAt' | 'pickedUpAt' | 'deliveredAt' | 'priorityScore' | 'expiryRisk' | 'estMealsServed' | 'smartMatches'>) => {
    const id = `DON-00${donations.length + 1}`;
    
    // AI Calculations emulating on-device intelligence
    const estMeals = parseInt(newDonationData.quantity) || 45;
    const priority = parseFloat((Math.random() * 3 + 7).toFixed(1)); // Priority score (7.0 - 10.0)
    const risk = estMeals > 80 ? 'High' : 'Medium';

    const completeDonation: Donation = {
      ...newDonationData,
      id,
      status: 'pending',
      createdAt: new Date().toISOString(),
      restaurantName: currentUser?.orgName || 'ABC Restaurant',
      ngoName: null,
      volunteerName: null,
      volunteerPhone: null,
      assignedAt: null,
      pickedUpAt: null,
      deliveredAt: null,
      priorityScore: priority,
      expiryRisk: risk,
      estMealsServed: estMeals,
      smartMatches: ['Helping Hands Foundation', 'Anantha Shelter', 'Joy Orphanage']
    };

    setDonations([completeDonation, ...donations]);

    // Create Firebase FCM alert
    const newAlert: AppNotification = {
      id: `NTF-00${notifications.length + 1}`,
      title: 'New Surplus Listed',
      message: `${currentUser?.orgName || 'ABC Restaurant'} listed ${newDonationData.quantity} of ${newDonationData.foodName} near you.`,
      timestamp: 'Just now',
      read: false,
      type: 'info'
    };
    setNotifications([newAlert, ...notifications]);
  };

  // NGO CLAIM DONATION METHOD
  const handleAcceptDonation = (id: string, ngoName: string) => {
    setDonations(donations.map(donation => {
      if (donation.id === id) {
        return {
          ...donation,
          status: 'accepted',
          ngoName,
          assignedAt: new Date().toISOString()
        };
      }
      return donation;
    }));

    // Alert donor of acceptance
    const targetDonation = donations.find(d => d.id === id);
    const newAlert: AppNotification = {
      id: `NTF-00${notifications.length + 1}`,
      title: 'Donation Accepted',
      message: `${ngoName} has accepted and claimed ${targetDonation?.foodName || 'your listed items'}. Dispatching rider...`,
      timestamp: 'Just now',
      read: false,
      type: 'success'
    };
    setNotifications([newAlert, ...notifications]);
  };

  // NGO DISPATCH VOLUNTEER METHOD
  const handleAssignVolunteer = (donationId: string, volunteerId: string) => {
    const targetVolunteer = volunteers.find(v => v.id === volunteerId);
    if (!targetVolunteer) return;

    setDonations(donations.map(donation => {
      if (donation.id === donationId) {
        return {
          ...donation,
          status: 'assigned',
          volunteerName: targetVolunteer.name,
          volunteerPhone: targetVolunteer.phone
        };
      }
      return donation;
    }));

    // Busy volunteer state update
    setVolunteers(volunteers.map(v => {
      if (v.id === volunteerId) {
        return { ...v, status: 'busy' };
      }
      return v;
    }));

    // Alert dispatch
    const targetDonation = donations.find(d => d.id === donationId);
    const newAlert: AppNotification = {
      id: `NTF-00${notifications.length + 1}`,
      title: 'Rider Dispatched',
      message: `Rider ${targetVolunteer.name} is on the way to pick up ${targetDonation?.foodName} from ${targetDonation?.restaurantName}.`,
      timestamp: 'Just now',
      read: false,
      type: 'info'
    };
    setNotifications([newAlert, ...notifications]);
  };

  // GENERAL STATUS HANDLER
  const handleUpdateStatus = (id: string, status: Donation['status']) => {
    setDonations(donations.map(donation => {
      if (donation.id === id) {
        const completedUpdate = {
          ...donation,
          status
        };

        if (status === 'picked_up') {
          completedUpdate.pickedUpAt = new Date().toISOString();
        } else if (status === 'delivered') {
          completedUpdate.deliveredAt = new Date().toISOString();
        }

        return completedUpdate;
      }
      return donation;
    }));

    const targetDonation = donations.find(d => d.id === id);
    let title = 'Trip Status Update';
    let msg = `Donation status for ${targetDonation?.foodName} updated to ${status}.`;

    if (status === 'picked_up') {
      title = 'Food Picked Up';
      msg = `${targetDonation?.volunteerName} has successfully verified and loaded food from ${targetDonation?.restaurantName}. Transit started.`;
    } else if (status === 'delivered') {
      title = 'Donation Completed! 🎉';
      msg = `Excellent! ${targetDonation?.foodName} has been delivered to ${targetDonation?.ngoName || 'shelter'}. Feed complete.`;

      // Free volunteer state update & reward increment
      if (targetDonation?.volunteerName) {
        setVolunteers(volunteers.map(v => {
          if (v.name === targetDonation.volunteerName) {
            return {
              ...v,
              status: 'available',
              completedDeliveries: v.completedDeliveries + 1
            };
          }
          return v;
        }));
      }

      // Add leaderboard/meals donated impact update
      if (targetDonation?.restaurantName) {
        setLeaderboard(leaderboard.map(item => {
          if (item.restaurantName === targetDonation.restaurantName) {
            const extraMeals = targetDonation.estMealsServed;
            const updatedMeals = item.mealsDonated + extraMeals;
            const updatedKg = item.totalDonatedKg + Math.round(extraMeals * 0.4);
            let tier: LeaderboardItem['tier'] = item.tier;

            if (updatedMeals >= 500) tier = 'Platinum';
            else if (updatedMeals >= 300) tier = 'Gold';
            else if (updatedMeals >= 150) tier = 'Silver';

            return {
              ...item,
              mealsDonated: updatedMeals,
              totalDonatedKg: updatedKg,
              tier,
              badge: `🏆 ${tier} Donor`
            };
          }
          return item;
        }));
      }
    }

    setNotifications([{
      id: `NTF-00${notifications.length + 1}`,
      title,
      message: msg,
      timestamp: 'Just now',
      read: false,
      type: status === 'delivered' ? 'success' : 'info'
    }, ...notifications]);
  };

  // ADMIN BROADCAST SYSTEM
  const handleAddAnnouncement = (msg: string) => {
    const alertId = `NTF-00${notifications.length + 1}`;
    const newBroadcast: AppNotification = {
      id: alertId,
      title: '🚨 Admin System Broadcast',
      message: msg,
      timestamp: 'Just now',
      read: false,
      type: 'warning'
    };
    setNotifications([newBroadcast, ...notifications]);
  };

  // ADMIN APPROVE RESTAURANT / NGO METHOD
  const handleApprovePartner = (name: string) => {
    const newAlert: AppNotification = {
      id: `NTF-00${notifications.length + 1}`,
      title: 'Partner Verified ✓',
      message: `Admin has approved credentials and authorized ${name} to participate in Akshaya Patra network.`,
      timestamp: 'Just now',
      read: false,
      type: 'success'
    };
    setNotifications([newAlert, ...notifications]);
  };

  // NOTIFICATION UTILS
  const handleMarkRead = (id: string) => {
    setNotifications(notifications.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const handleClearAll = () => {
    setNotifications([]);
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-between" id="platform-root">
      
      {/* PERSISTENT MULTI-PLATFORM PROTOTYPE SWITCHER HEADER */}
      <div className="bg-slate-950 text-white border-b border-slate-800 py-3.5 px-6 flex flex-col md:flex-row justify-between items-center gap-4 relative z-50 shadow-lg">
        
        <div className="flex items-center gap-3">
          <div className="bg-green-700 p-2 rounded-xl text-white font-black shadow-md flex items-center justify-center">
            <Layers className="h-5 w-5 animate-spin-slow" />
          </div>
          <div>
            <h1 className="text-sm font-black tracking-wider uppercase text-white flex items-center gap-1.5">
              Akshaya Patra <span className="bg-orange-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full tracking-normal">MULTIPLATFORM</span>
            </h1>
            <p className="text-xxs text-slate-400">
              Synchronized Local Firebase Database Emulation • Responsive Startup Prototype
            </p>
          </div>
        </div>

        {/* Dynamic Platform Toggle Switcher */}
        <div className="flex items-center gap-2 bg-slate-900 p-1.5 rounded-2xl border border-slate-800">
          <button
            onClick={() => setPlatformView('web')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xxs font-black transition ${
              platformView === 'web' 
                ? 'bg-green-700 text-white shadow' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Monitor className="h-4 w-4" /> Laptop Web App
          </button>
          
          <button
            onClick={() => setPlatformView('mobile')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xxs font-black transition ${
              platformView === 'mobile' 
                ? 'bg-green-700 text-white shadow' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="h-4 w-4" /> Simulated Mobile App
          </button>
        </div>

        {/* Live Notification Bell Toggle */}
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setShowNotificationCenter(!showNotificationCenter)}
            className="relative p-2 bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-white rounded-xl transition border border-slate-800"
            title="Toggle Notifications Tray"
          >
            🔔
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-orange-500 text-white text-[10px] font-black h-5 w-5 rounded-full flex items-center justify-center animate-bounce">
                {unreadCount}
              </span>
            )}
          </button>

          <div className="hidden lg:flex items-center gap-2 bg-slate-900/60 px-3 py-1.5 rounded-xl border border-slate-800/40 text-xxs font-semibold">
            <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse"></span>
            <span className="text-green-400">Firebase DB Active</span>
          </div>
        </div>

      </div>

      {/* FLOATING NOTIFICATION TRAY OVERLAY */}
      {showNotificationCenter && (
        <div className="absolute top-18 right-6 z-50 animate-scale-up">
          <NotificationCenter 
            notifications={notifications} 
            onMarkRead={handleMarkRead} 
            onClearAll={handleClearAll} 
          />
        </div>
      )}

      {/* RENDER BODY FOR PLATFORM SCREEN */}
      <div className="flex-1 flex flex-col justify-center">
        {currentUser === null ? (
          <RoleSelector 
            onRoleSelected={(role, details) => {
              setCurrentUser({
                name: details.name,
                role,
                email: details.email,
                orgName: details.orgName,
                phone: details.phone
              });
            }} 
          />
        ) : platformView === 'web' ? (
          <WebView
            donations={donations}
            volunteers={volunteers}
            notifications={notifications}
            leaderboard={leaderboard}
            currentUser={{ ...currentUser, role: currentUser.role }}
            onLogout={handleLogout}
            onAddDonation={handleAddDonation}
            onAcceptDonation={handleAcceptDonation}
            onAssignVolunteer={handleAssignVolunteer}
            onUpdateStatus={handleUpdateStatus}
            onTriggerNotification={(title, message, type) => {
              setNotifications([{
                id: `NTF-00${notifications.length + 1}`,
                title,
                message,
                timestamp: 'Just now',
                read: false,
                type
              }, ...notifications]);
            }}
            onAddAnnouncement={handleAddAnnouncement}
            onApprovePartner={handleApprovePartner}
          />
        ) : (
          <MobileView
            donations={donations}
            volunteers={volunteers}
            notifications={notifications}
            leaderboard={leaderboard}
            currentUser={{ ...currentUser, role: currentUser.role }}
            onLogout={handleLogout}
            onAddDonation={handleAddDonation}
            onAcceptDonation={handleAcceptDonation}
            onAssignVolunteer={handleAssignVolunteer}
            onUpdateStatus={handleUpdateStatus}
            onTriggerNotification={(title, message, type) => {
              setNotifications([{
                id: `NTF-00${notifications.length + 1}`,
                title,
                message,
                timestamp: 'Just now',
                read: false,
                type
              }, ...notifications]);
            }}
          />
        )}
      </div>

    </div>
  );
}
