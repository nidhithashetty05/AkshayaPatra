import { Donation, AppNotification, LeaderboardItem, Volunteer } from '../types';

export const initialDonations: Donation[] = [
  {
    id: 'DON-001',
    foodName: 'Vegetable Biryani',
    category: 'Main Course',
    vegNonVeg: 'Veg',
    quantity: '50 Meals',
    prepTime: '12:30 PM',
    expiryTime: '5:00 PM',
    pickupAddress: 'Road No. 36, Near Metro Station, Madhapur',
    location: 'Madhapur, Hyderabad',
    condition: 'Freshly prepared surplus from buffet',
    specialInstructions: 'Keep in insulated containers. Handle with care.',
    status: 'assigned',
    createdAt: '2026-07-03T13:00:00Z',
    restaurantName: 'ABC Restaurant',
    ngoName: 'Helping Hands Foundation',
    volunteerName: 'Rahul Kumar',
    volunteerPhone: '+91 98765 43210',
    assignedAt: '2026-07-03T13:15:00Z',
    pickedUpAt: null,
    deliveredAt: null,
    distanceKm: 2.1,
    priorityScore: 8.5,
    expiryRisk: 'Medium',
    estMealsServed: 50,
    smartMatches: ['Helping Hands Foundation', 'Anantha Shelter', 'Hope Foundation']
  },
  {
    id: 'DON-002',
    foodName: 'Chocolate Cupcakes & Pastries',
    category: 'Bakery',
    vegNonVeg: 'Veg',
    quantity: '30 Pieces',
    prepTime: '09:00 AM',
    expiryTime: '09:30 PM',
    pickupAddress: 'Hitech City Road, Phase 2',
    location: 'Hitech City, Hyderabad',
    condition: 'Freshly baked unsold items',
    specialInstructions: 'Refrigeration recommended. Keep upright.',
    status: 'pending',
    createdAt: '2026-07-03T14:30:00Z',
    restaurantName: 'Bakers Delight',
    ngoName: null,
    volunteerName: null,
    volunteerPhone: null,
    assignedAt: null,
    pickedUpAt: null,
    deliveredAt: null,
    distanceKm: 1.2,
    priorityScore: 6.2,
    expiryRisk: 'Low',
    estMealsServed: 15,
    smartMatches: ['Joy Orphanage', 'Feeding India NGO', 'Anantha Shelter']
  },
  {
    id: 'DON-003',
    foodName: 'Chicken Pulav & Raita',
    category: 'Main Course',
    vegNonVeg: 'Non-Veg',
    quantity: '120 Meals',
    prepTime: '01:00 PM',
    expiryTime: '04:00 PM',
    pickupAddress: 'ISB Road, Gachibowli',
    location: 'Gachibowli, Hyderabad',
    condition: 'Leftover from corporate event banquet',
    specialInstructions: 'Must be picked up in a reefer vehicle or cold storage box immediately.',
    status: 'accepted',
    createdAt: '2026-07-03T13:45:00Z',
    restaurantName: 'Grand Banquet Hall',
    ngoName: 'Feeding India NGO',
    volunteerName: null,
    volunteerPhone: null,
    assignedAt: null,
    pickedUpAt: null,
    deliveredAt: null,
    distanceKm: 4.5,
    priorityScore: 9.8,
    expiryRisk: 'High',
    estMealsServed: 120,
    smartMatches: ['Feeding India NGO', 'Helping Hands Foundation', 'Anantha Shelter']
  },
  {
    id: 'DON-004',
    foodName: 'Assorted Bread & Buns',
    category: 'Bakery',
    vegNonVeg: 'Veg',
    quantity: '15 kg',
    prepTime: '07:00 AM',
    expiryTime: '10:00 PM',
    pickupAddress: 'Inorbit Mall Area, Madhapur',
    location: 'Madhapur, Hyderabad',
    condition: 'Excess baked bread inventory',
    specialInstructions: 'Store in dry place. Ready to eat.',
    status: 'delivered',
    createdAt: '2026-07-02T10:00:00Z',
    restaurantName: 'Bread & Butter Co.',
    ngoName: 'Anantha Shelter',
    volunteerName: 'Vikas Patel',
    volunteerPhone: '+91 91234 56789',
    assignedAt: '2026-07-02T10:15:00Z',
    pickedUpAt: '2026-07-02T11:00:00Z',
    deliveredAt: '2026-07-02T11:45:00Z',
    distanceKm: 2.8,
    priorityScore: 7.0,
    expiryRisk: 'Low',
    estMealsServed: 40,
    smartMatches: ['Anantha Shelter', 'Joy Orphanage']
  },
  {
    id: 'DON-005',
    foodName: 'North Indian Lunch Thali',
    category: 'Main Course',
    vegNonVeg: 'Veg',
    quantity: '80 Meals',
    prepTime: '12:00 PM',
    expiryTime: '03:30 PM',
    pickupAddress: 'Kondapur Main Road',
    location: 'Kondapur, Hyderabad',
    condition: 'Unserved thali components',
    specialInstructions: 'Vegetables and dal stored separately in stainless steel containers.',
    status: 'delivered',
    createdAt: '2026-07-03T12:00:00Z',
    restaurantName: 'Pind Balluchi',
    ngoName: 'Helping Hands Foundation',
    volunteerName: 'Rahul Kumar',
    volunteerPhone: '+91 98765 43210',
    assignedAt: '2026-07-03T12:10:00Z',
    pickedUpAt: '2026-07-03T12:35:00Z',
    deliveredAt: '2026-07-03T13:05:00Z',
    distanceKm: 3.2,
    priorityScore: 9.2,
    expiryRisk: 'High',
    estMealsServed: 80,
    smartMatches: ['Helping Hands Foundation', 'Hope Foundation']
  }
];

export const initialVolunteers: Volunteer[] = [
  {
    id: 'VOL-001',
    name: 'Rahul Kumar',
    phone: '+91 98765 43210',
    status: 'busy',
    completedDeliveries: 48,
    rating: 4.9,
    currentLocation: 'Madhapur, Hyderabad'
  },
  {
    id: 'VOL-002',
    name: 'Anjali Sharma',
    phone: '+91 87654 32109',
    status: 'available',
    completedDeliveries: 32,
    rating: 4.8,
    currentLocation: 'Jubilee Hills, Hyderabad'
  },
  {
    id: 'VOL-003',
    name: 'Vikas Patel',
    phone: '+91 91234 56789',
    status: 'available',
    completedDeliveries: 75,
    rating: 4.95,
    currentLocation: 'Kondapur, Hyderabad'
  },
  {
    id: 'VOL-004',
    name: 'Pooja Reddy',
    phone: '+91 76543 21098',
    status: 'offline',
    completedDeliveries: 15,
    rating: 4.5,
    currentLocation: 'Gachibowli, Hyderabad'
  }
];

export const initialNotifications: AppNotification[] = [
  {
    id: 'NTF-001',
    title: 'New Donation Available',
    message: 'Bakers Delight has listed 30 Pieces of Chocolate Cupcakes & Pastries in Hitech City.',
    timestamp: '14 mins ago',
    read: false,
    type: 'info'
  },
  {
    id: 'NTF-002',
    title: 'NGO Accepted Your Donation',
    message: 'Helping Hands Foundation has accepted your donation of Vegetable Biryani.',
    timestamp: '1 hour ago',
    read: true,
    type: 'success'
  },
  {
    id: 'NTF-003',
    title: 'Volunteer Assigned',
    message: 'Volunteer Rahul Kumar has been assigned to pick up donation DON-001 from ABC Restaurant.',
    timestamp: '45 mins ago',
    read: false,
    type: 'info'
  },
  {
    id: 'NTF-004',
    title: 'Achievement Unlocked: Gold Badge!',
    message: 'Congratulations! ABC Restaurant has reached 500 meals donated, unlocking the Gold Donor Badge!',
    timestamp: '2 hours ago',
    read: false,
    type: 'achievement'
  },
  {
    id: 'NTF-005',
    title: 'Food Delivered Successfully',
    message: '80 Meals from Pind Balluchi have been delivered to Helping Hands Foundation shelter.',
    timestamp: '3 hours ago',
    read: true,
    type: 'success'
  }
];

export const initialLeaderboard: LeaderboardItem[] = [
  {
    restaurantName: 'ABC Restaurant',
    totalDonatedKg: 420,
    mealsDonated: 512,
    tier: 'Gold',
    badge: '🏆 Gold Donor'
  },
  {
    restaurantName: 'Pind Balluchi',
    totalDonatedKg: 380,
    mealsDonated: 440,
    tier: 'Gold',
    badge: '🏆 Gold Donor'
  },
  {
    restaurantName: 'Grand Banquet Hall',
    totalDonatedKg: 850,
    mealsDonated: 920,
    tier: 'Platinum',
    badge: '👑 Platinum Donor'
  },
  {
    restaurantName: 'Bakers Delight',
    totalDonatedKg: 120,
    mealsDonated: 160,
    tier: 'Silver',
    badge: '🥈 Silver Donor'
  },
  {
    restaurantName: 'Bread & Butter Co.',
    totalDonatedKg: 95,
    mealsDonated: 110,
    tier: 'Bronze',
    badge: '🥉 Bronze Donor'
  }
];

// Rich analytics data for beautiful charts & widgets
export const analyticsStats = {
  totalRestaurants: 45,
  totalNGOs: 18,
  totalVolunteers: 64,
  totalDonations: 480,
  mealsSaved: 12450,
  foodWasteReducedKg: 5200,
  co2SavedKg: 9880, // 1 kg food waste ~ 1.9 kg CO2
  waterSavedLitres: 340000, // 1 kg food waste ~ 65 litres water on average
  familiesHelped: 3120,
  donationSuccessRate: 98.4,
  monthlyGrowthPct: 15.8,
  
  dailyTrends: [
    { day: 'Mon', count: 18, meals: 420 },
    { day: 'Tue', count: 24, meals: 550 },
    { day: 'Wed', count: 22, meals: 490 },
    { day: 'Thu', count: 28, meals: 680 },
    { day: 'Fri', count: 35, meals: 820 },
    { day: 'Sat', count: 48, meals: 1100 },
    { day: 'Sun', count: 42, meals: 950 }
  ],
  
  categoryDistribution: [
    { name: 'Main Course', value: 45, color: '#2E7D32' },
    { name: 'Bakery Items', value: 20, color: '#FF9800' },
    { name: 'Groceries/Veggies', value: 15, color: '#4CAF50' },
    { name: 'Cooked Fast Food', value: 12, color: '#FFC107' },
    { name: 'Desserts & Sweets', value: 8, color: '#E91E63' }
  ],
  
  monthlyTrends: [
    { month: 'Jan', foodSaved: 680, co2: 1290 },
    { month: 'Feb', foodSaved: 740, co2: 1400 },
    { month: 'Mar', foodSaved: 890, co2: 1690 },
    { month: 'Apr', foodSaved: 950, co2: 1800 },
    { month: 'May', foodSaved: 1100, co2: 2090 },
    { month: 'Jun', foodSaved: 1240, co2: 2350 }
  ]
};
