import React, { useState, useEffect } from 'react';
import { UserRole } from '../types';
import { Shield, Users, Heart, Store, ChevronRight, Lock, Mail, ArrowLeft, LogIn, Compass, CheckCircle } from 'lucide-react';

interface RoleSelectorProps {
  onRoleSelected: (role: UserRole, userDetails: { name: string; orgName: string; email: string; phone: string }) => void;
}

export const RoleSelector: React.FC<RoleSelectorProps> = ({ onRoleSelected }) => {
  const [step, setStep] = useState<'splash' | 'login' | 'register' | 'forgot' | 'role_select'>('splash');
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  
  // Login credentials state
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [orgName, setOrgName] = useState('');
  const [phone, setPhone] = useState('');

  // Auto populate mock inputs for fast demonstration
  const handlePreFill = (role: UserRole) => {
    if (role === 'donor') {
      setEmail('manager@abcrestaurant.com');
      setName('John Doe');
      setOrgName('ABC Restaurant');
      setPhone('+91 99001 12233');
    } else if (role === 'ngo') {
      setEmail('director@helpinghands.org');
      setName('Saraswathi Devi');
      setOrgName('Helping Hands Foundation');
      setPhone('+91 94412 34567');
    } else if (role === 'volunteer') {
      setEmail('rahul.kumar@gmail.com');
      setName('Rahul Kumar');
      setOrgName('Independent Volunteer');
      setPhone('+91 98765 43210');
    } else {
      setEmail('admin@akshayapatra.gov');
      setName('Super Admin');
      setOrgName('Akshaya Patra Headquarters');
      setPhone('+91 90000 11111');
    }
  };

  useEffect(() => {
    if (selectedRole) {
      handlePreFill(selectedRole);
    }
  }, [selectedRole]);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      alert('Please select a role or enter an email address.');
      return;
    }
    setStep('role_select');
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('role_select');
  };

  const handleGoogleSignIn = () => {
    // Simulate Google Sign-In with a default role
    setSelectedRole('donor');
    setEmail('investor.demo@google.com');
    setName('Demo Guest');
    setOrgName('Investor Showcase');
    setPhone('+91 98989 89898');
    setStep('role_select');
  };

  const handleProceed = () => {
    if (!selectedRole) return;
    
    // Fallbacks
    const finalName = name || (selectedRole === 'donor' ? 'John Doe' : selectedRole === 'ngo' ? 'Saraswathi Devi' : selectedRole === 'volunteer' ? 'Rahul Kumar' : 'Super Admin');
    const finalOrg = orgName || (selectedRole === 'donor' ? 'ABC Restaurant' : selectedRole === 'ngo' ? 'Helping Hands Foundation' : selectedRole === 'volunteer' ? 'Independent Volunteer' : 'Akshaya Patra HQ');
    const finalEmail = email || `${selectedRole}@example.com`;
    const finalPhone = phone || '+91 90000 00000';

    onRoleSelected(selectedRole, {
      name: finalName,
      orgName: finalOrg,
      email: finalEmail,
      phone: finalPhone
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center p-4 relative overflow-hidden" id="role-selector-wrapper">
      {/* Decorative colored backgrounds */}
      <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-green-100 rounded-full filter blur-3xl opacity-60"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-orange-100 rounded-full filter blur-3xl opacity-60"></div>

      {/* Main card panel */}
      <div className="w-full max-w-lg bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden relative z-10 transition-all duration-300">
        
        {/* Splash Screen Mode */}
        {step === 'splash' && (
          <div className="p-8 text-center" id="splash-step">
            <div className="mb-6 flex justify-center">
              <img
                src="/src/assets/images/akshaya_patra_logo_1783152125223.jpg"
                alt="Akshaya Patra Logo"
                className="h-36 w-auto object-contain drop-shadow-md rounded-2xl transition-transform duration-300 hover:scale-105 cursor-pointer"
                referrerPolicy="no-referrer"
              />
            </div>
            
            <h1 className="text-[42px] leading-[41px] font-bold font-serif text-green-800 tracking-tight mb-2">
              AKSHAYA PATRA
            </h1>
            <p className="text-orange-600 font-calligraphy text-2xl font-bold mb-4">
              Where Every Meal Finds a Home.
            </p>
            
            <p className="text-gray-600 text-sm max-w-sm mx-auto mb-8 leading-relaxed">
              Connecting restaurants, hotels, and bakeries with NGOs, shelters, and passionate volunteers to distribute surplus food securely.
            </p>

            <div className="space-y-3">
              <button
                onClick={() => setStep('login')}
                className="w-full bg-green-700 hover:bg-green-800 text-white font-bold py-3.5 px-6 rounded-2xl shadow-md transition transform hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center gap-2 group"
                id="btn-get-started"
              >
                Get Started
                <ChevronRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
              </button>
              
              <div className="text-xxs text-gray-400 mt-4 flex items-center justify-center gap-1">
                <CheckCircle className="h-3 w-3 text-green-600" /> 100% Shared Firebase Sync Active
              </div>
            </div>
          </div>
        )}

        {/* Login Screen Mode */}
        {step === 'login' && (
          <div className="p-8" id="login-step">
            <div className="flex items-center gap-2 mb-6">
              <button 
                onClick={() => setStep('splash')}
                className="p-1.5 rounded-xl hover:bg-gray-100 transition text-gray-500"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
              <div>
                <h2 className="text-xl font-bold text-gray-900">Sign In</h2>
                <p className="text-xs text-gray-500">Access your Akshaya Patra Account</p>
              </div>
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-3.5 h-4.5 w-4.5 text-gray-400" />
                  <input
                    type="email"
                    required
                    placeholder="name@organization.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-11 pr-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 focus:border-transparent text-sm"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-xs font-semibold text-gray-700">Password</label>
                  <button 
                    type="button"
                    onClick={() => setStep('forgot')}
                    className="text-xxs font-semibold text-orange-600 hover:underline"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3.5 h-4.5 w-4.5 text-gray-400" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-11 pr-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 focus:border-transparent text-sm"
                  />
                </div>
              </div>

              <div className="bg-orange-50/70 border border-orange-100 rounded-xl p-3 text-xxs text-gray-600 leading-normal">
                💡 <span className="font-semibold text-orange-800">Demo Mode:</span> You can sign in with any credentials. Simply click the primary button below, and you will select a workspace role next.
              </div>

              <button
                type="submit"
                className="w-full bg-green-700 hover:bg-green-800 text-white font-bold py-3 px-4 rounded-xl shadow-md transition flex justify-center items-center gap-2"
              >
                <LogIn className="h-4.5 w-4.5" /> Continue with Password
              </button>
            </form>

            <div className="relative my-6 text-center">
              <hr className="border-gray-100" />
              <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white px-3 text-xxs font-semibold text-gray-400 uppercase tracking-widest">Or</span>
            </div>

            <button
              onClick={handleGoogleSignIn}
              className="w-full bg-white border border-gray-200 text-gray-700 hover:bg-gray-50 font-semibold py-3 px-4 rounded-xl shadow-xs transition flex justify-center items-center gap-2 text-sm"
            >
              <img src="https://www.svgrepo.com/show/475656/google-color.svg" className="h-4.5 w-4.5" alt="Google" referrerPolicy="no-referrer" />
              Sign In with Google
            </button>

            <p className="text-center text-xs text-gray-500 mt-6">
              Don't have an account?{' '}
              <button onClick={() => setStep('register')} className="text-green-700 hover:underline font-bold">
                Register here
              </button>
            </p>
          </div>
        )}

        {/* Register Screen Mode */}
        {step === 'register' && (
          <div className="p-8" id="register-step">
            <div className="flex items-center gap-2 mb-6">
              <button 
                onClick={() => setStep('login')}
                className="p-1.5 rounded-xl hover:bg-gray-100 transition text-gray-500"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
              <div>
                <h2 className="text-xl font-bold text-gray-900">Create Account</h2>
                <p className="text-xs text-gray-500">Join the Akshaya Patra network</p>
              </div>
            </div>

            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Anjali Sharma"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Organization Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Bakers Delight"
                    value={orgName}
                    onChange={(e) => setOrgName(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  placeholder="contact@org.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Phone Number</label>
                <input
                  type="text"
                  required
                  placeholder="+91 99887 76655"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Secure Password</label>
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-green-700 hover:bg-green-800 text-white font-bold py-3 px-4 rounded-xl shadow-md transition flex justify-center items-center gap-2"
              >
                Register & Select Role
              </button>
            </form>
          </div>
        )}

        {/* Forgot Password Mode */}
        {step === 'forgot' && (
          <div className="p-8 text-center" id="forgot-step">
            <div className="mb-4 inline-flex p-3.5 rounded-full bg-orange-50 text-orange-600">
              <Lock className="h-8 w-8" />
            </div>
            
            <h2 className="text-xl font-bold text-gray-900 mb-2">Forgot Password</h2>
            <p className="text-xs text-gray-500 max-w-xs mx-auto mb-6">
              Enter your email and we'll simulate a Firebase password reset instructions link.
            </p>

            <div className="space-y-4 text-left">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Email Address</label>
                <input
                  type="email"
                  placeholder="name@organization.com"
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-sm"
                />
              </div>

              <button
                onClick={() => {
                  alert('Firebase Password Reset Link generated (Simulated). Check your console!');
                  setStep('login');
                }}
                className="w-full bg-green-700 hover:bg-green-800 text-white font-bold py-3 px-4 rounded-xl shadow-md transition"
              >
                Send Recovery Instructions
              </button>

              <button
                onClick={() => setStep('login')}
                className="w-full text-xs text-gray-500 hover:underline text-center block font-semibold"
              >
                Back to Login
              </button>
            </div>
          </div>
        )}

        {/* Role Selection Screen Mode */}
        {step === 'role_select' && (
          <div className="p-8" id="role-select-step">
            <h2 className="text-2xl font-bold text-gray-900 text-center mb-1">Select Workspace Role</h2>
            <p className="text-xs text-gray-500 text-center mb-6">
              Choose your portal role to experience customized layouts, statistics, and workflows.
            </p>

            <div className="grid grid-cols-2 gap-4 mb-6">
              {/* Restaurant / Donor Card */}
              <button
                onClick={() => setSelectedRole('donor')}
                className={`p-4 rounded-2xl border-2 text-left transition duration-200 flex flex-col justify-between h-36 ${
                  selectedRole === 'donor' 
                    ? 'border-green-700 bg-green-50/50 text-green-900' 
                    : 'border-gray-100 hover:border-gray-200 bg-white text-gray-700'
                }`}
              >
                <div className={`p-2 rounded-xl inline-flex self-start ${selectedRole === 'donor' ? 'bg-green-700 text-white' : 'bg-gray-50 text-gray-500'}`}>
                  <Store className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">Food Donor</h3>
                  <p className="text-xxs text-gray-500 leading-tight mt-1">Restaurants, banquets, bakeries & supermarkets.</p>
                </div>
              </button>

              {/* NGO / Receiver Card */}
              <button
                onClick={() => setSelectedRole('ngo')}
                className={`p-4 rounded-2xl border-2 text-left transition duration-200 flex flex-col justify-between h-36 ${
                  selectedRole === 'ngo' 
                    ? 'border-green-700 bg-green-50/50 text-green-900' 
                    : 'border-gray-100 hover:border-gray-200 bg-white text-gray-700'
                }`}
              >
                <div className={`p-2 rounded-xl inline-flex self-start ${selectedRole === 'ngo' ? 'bg-green-700 text-white' : 'bg-gray-50 text-gray-500'}`}>
                  <Heart className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">Food Receiver (NGO)</h3>
                  <p className="text-xxs text-gray-500 leading-tight mt-1">Shelters, orphanages, and community programs.</p>
                </div>
              </button>

              {/* Volunteer Card */}
              <button
                onClick={() => setSelectedRole('volunteer')}
                className={`p-4 rounded-2xl border-2 text-left transition duration-200 flex flex-col justify-between h-36 ${
                  selectedRole === 'volunteer' 
                    ? 'border-green-700 bg-green-50/50 text-green-900' 
                    : 'border-gray-100 hover:border-gray-200 bg-white text-gray-700'
                }`}
              >
                <div className={`p-2 rounded-xl inline-flex self-start ${selectedRole === 'volunteer' ? 'bg-green-700 text-white' : 'bg-gray-50 text-gray-500'}`}>
                  <Users className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">Volunteer</h3>
                  <p className="text-xxs text-gray-500 leading-tight mt-1">Transporters, riders, and safety verifiers.</p>
                </div>
              </button>

              {/* Admin Card */}
              <button
                onClick={() => setSelectedRole('admin')}
                className={`p-4 rounded-2xl border-2 text-left transition duration-200 flex flex-col justify-between h-36 ${
                  selectedRole === 'admin' 
                    ? 'border-green-700 bg-green-50/50 text-green-900' 
                    : 'border-gray-100 hover:border-gray-200 bg-white text-gray-700'
                }`}
              >
                <div className={`p-2 rounded-xl inline-flex self-start ${selectedRole === 'admin' ? 'bg-green-700 text-white' : 'bg-gray-50 text-gray-500'}`}>
                  <Shield className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">Platform Admin</h3>
                  <p className="text-xxs text-gray-500 leading-tight mt-1">Verification approvals, monitoring, and statistics reporting.</p>
                </div>
              </button>
            </div>

            {selectedRole && (
              <div className="bg-green-50 border border-green-100 rounded-xl p-3 mb-4 flex items-center gap-2">
                <CheckCircle className="h-4.5 w-4.5 text-green-700 flex-shrink-0" />
                <p className="text-xxs text-green-800 leading-relaxed">
                  Excellent choice! Selected <span className="font-bold capitalize">{selectedRole}</span>. Click below to enter the live prototype dashboard.
                </p>
              </div>
            )}

            <button
              onClick={handleProceed}
              disabled={!selectedRole}
              className={`w-full font-bold py-3.5 px-6 rounded-xl transition duration-200 flex items-center justify-center gap-2 shadow-md ${
                selectedRole 
                  ? 'bg-green-700 hover:bg-green-800 text-white cursor-pointer transform hover:-translate-y-0.5' 
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              }`}
            >
              Enter Dashboard Portal
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
