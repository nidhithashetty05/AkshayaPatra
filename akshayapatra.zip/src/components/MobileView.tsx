import React, { useState, useRef } from 'react';
import { Donation, AppNotification, LeaderboardItem, Volunteer, UserRole } from '../types';
import { 
  Home, ClipboardList, Bell, User, MapPin, Clock, CheckCircle2, Navigation, 
  Sparkles, Award, ShieldAlert, Check, ChevronRight, Map, ArrowLeft, RefreshCw,
  TrendingUp, Store, Heart, Play, Eye, Phone, Camera, QrCode, PenTool, CheckSquare,
  History, CheckCircle, AlertTriangle, MessageSquare, Volume2, ShieldCheck
} from 'lucide-react';

interface MobileViewProps {
  donations: Donation[];
  volunteers: Volunteer[];
  notifications: AppNotification[];
  leaderboard: LeaderboardItem[];
  currentUser: { name: string; orgName: string; email: string; phone: string; role: UserRole };
  onLogout: () => void;
  onAddDonation: (donation: Omit<Donation, 'id' | 'createdAt' | 'restaurantName' | 'ngoName' | 'volunteerName' | 'volunteerPhone' | 'assignedAt' | 'pickedUpAt' | 'deliveredAt' | 'priorityScore' | 'expiryRisk' | 'estMealsServed' | 'smartMatches'>) => void;
  onAcceptDonation: (id: string, ngoName: string) => void;
  onAssignVolunteer: (id: string, volunteerId: string) => void;
  onUpdateStatus: (id: string, status: Donation['status']) => void;
  onTriggerNotification?: (title: string, message: string, type: 'info' | 'success' | 'warning' | 'achievement') => void;
}

export const MobileView: React.FC<MobileViewProps> = ({
  donations,
  volunteers,
  notifications,
  leaderboard,
  currentUser,
  onLogout,
  onAddDonation,
  onAcceptDonation,
  onAssignVolunteer,
  onUpdateStatus,
  onTriggerNotification,
}) => {
  // Navigation for bottom bar
  const [activeTab, setActiveTab] = useState<'home' | 'active_pickup' | 'history' | 'notifications' | 'profile'>('home');
  const [selectedTask, setSelectedTask] = useState<Donation | null>(null);
  const [showDonateForm, setShowDonateForm] = useState(false);
  const [showSafetyChecklist, setShowSafetyChecklist] = useState<Donation | null>(null);

  // Volunteer specific states
  const [activeTaskStep, setActiveTaskStep] = useState<
    'assigned' | 'travelling_to_restaurant' | 'reached_restaurant' | 'pickup_verification' | 'picked_up' | 'reached_ngo' | 'delivery_confirmation' | 'success'
  >('assigned');

  // Simulated GPS Guidance State
  const [gpsNavigating, setGpsNavigating] = useState(false);
  const [gpsGuidanceText, setGpsGuidanceText] = useState('GPS ready. Click Start Navigation for audio cues.');

  // Simulated device/camera photo captures
  const [pickupPhotoCaptured, setPickupPhotoCaptured] = useState(false);
  const [pickupQrScanned, setPickupQrScanned] = useState(false);
  const [deliveryPhotoCaptured, setDeliveryPhotoCaptured] = useState(false);
  const [deliveryQrScanned, setDeliveryQrScanned] = useState(false);
  const [signatureVerified, setSignatureVerified] = useState(false);

  // Signature Canvas Drawing states
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasSigned, setHasSigned] = useState(false);

  // Food Safety Checklist for Volunteer Pickups
  const [volunteerSafetyChecklist, setVolunteerSafetyChecklist] = useState({
    foodFresh: false,
    properlyPacked: false,
    sealedContainers: false,
    quantityVerified: false,
    expiryConfirmed: false,
  });

  // Session stats incremented locally when a delivery completes successfully
  const [sessionCompletedCount, setSessionCompletedCount] = useState(0);

  // General Donate states
  const [foodName, setFoodName] = useState('');
  const [category, setCategory] = useState('Main Course');
  const [quantity, setQuantity] = useState('');
  const [expiryTime, setExpiryTime] = useState('5:00 PM');
  const [pickupAddress, setPickupAddress] = useState('');

  // Safety checklist states for NGO Acceptances
  const [safetyChecklist, setSafetyChecklist] = useState({
    freshFood: false,
    properPackaging: false,
    safeTemperature: false,
    cleanContainers: false,
    withinExpiry: false
  });

  // Timeline Step Helper
  const progressTimelineSteps = [
    { label: 'Assigned', desc: 'Rider assigned' },
    { label: 'Travelling', desc: 'Heading to restaurant' },
    { label: 'Arrived Rest.', desc: 'Reached food source' },
    { label: 'Food Loaded', desc: 'Food picked up' },
    { label: 'Travelling NGO', desc: 'Transit to shelter' },
    { label: 'Arrived NGO', desc: 'Reached NGO destination' },
    { label: 'Completed', desc: 'Meals delivered successfully' }
  ];

  const getActiveTimelineStepIndex = () => {
    switch (activeTaskStep) {
      case 'assigned': return 0;
      case 'travelling_to_restaurant': return 1;
      case 'reached_restaurant': return 2;
      case 'pickup_verification': return 3;
      case 'picked_up': return 4;
      case 'reached_ngo': return 5;
      case 'delivery_confirmation': return 5;
      case 'success': return 6;
      default: return 0;
    }
  };

  // -----------------------------------------------------------------
  // SIGNATURE DRAWING HANDLERS (Smooth mouse & touch support)
  // -----------------------------------------------------------------
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.strokeStyle = '#ea580c'; // Beautiful energetic orange ink
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    const rect = canvas.getBoundingClientRect();
    const x = ('touches' in e) ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = ('touches' in e) ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = ('touches' in e) ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = ('touches' in e) ? e.touches[0].clientY - rect.top : e.clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
    setHasSigned(true);
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasSigned(false);
    setSignatureVerified(false);
  };

  // -----------------------------------------------------------------
  // DUMMY CALLS / CAMERA VERIFICATION ALERTS
  // -----------------------------------------------------------------
  const triggerPhoneCall = (targetName: string, phoneNumber: string) => {
    onTriggerNotification?.('Simulated Phone Call Out', `Dialing ${targetName} at ${phoneNumber}...`, 'info');
    alert(`[RIDER SIMULATOR PHONE] Calling ${targetName} (${phoneNumber})...`);
  };

  const captureMockPhoto = (type: 'pickup' | 'delivery') => {
    if (type === 'pickup') {
      setPickupPhotoCaptured(true);
      onTriggerNotification?.('Camera Capture Completed', 'Freshly packed meals loaded and verified in insulated container.', 'success');
    } else {
      setDeliveryPhotoCaptured(true);
      onTriggerNotification?.('Camera Capture Completed', 'Signed delivery receipt photo logged into blockchain database.', 'success');
    }
  };

  const scanMockQrCode = (type: 'pickup' | 'delivery') => {
    if (type === 'pickup') {
      setPickupQrScanned(true);
      onTriggerNotification?.('QR Code Verified ✓', 'Donor cryptographic tag matches Akshaya Patra inventory.', 'success');
    } else {
      setDeliveryQrScanned(true);
      onTriggerNotification?.('QR Code Verified ✓', 'NGO shelter recipient signature token verified.', 'success');
    }
  };

  // -----------------------------------------------------------------
  // SUBMISSIONS
  // -----------------------------------------------------------------
  const handleDonateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!foodName || !quantity || !pickupAddress) {
      alert('Please fill out all mandatory fields.');
      return;
    }

    onAddDonation({
      foodName,
      category,
      vegNonVeg: 'Veg',
      quantity,
      prepTime: '12:00 PM',
      expiryTime,
      pickupAddress,
      location: 'Madhapur, Hyderabad',
      condition: 'Freshly prepared surplus',
      specialInstructions: 'Bring own bags.',
      distanceKm: 1.5
    });

    setFoodName('');
    setQuantity('');
    setPickupAddress('');
    setShowDonateForm(false);
    alert('Food donation listing added to shared database!');
  };

  const handleSafetyAccept = () => {
    if (!showSafetyChecklist) return;
    if (Object.values(safetyChecklist).some(v => !v)) {
      alert('You must verify all food safety checklist parameters before accepting.');
      return;
    }
    onAcceptDonation(showSafetyChecklist.id, currentUser.orgName);
    setShowSafetyChecklist(null);
    setSafetyChecklist({
      freshFood: false,
      properPackaging: false,
      safeTemperature: false,
      cleanContainers: false,
      withinExpiry: false
    });
  };

  // -----------------------------------------------------------------
  // BEAUTIFUL PROGRESS TRACKER GRAPHICS
  // -----------------------------------------------------------------
  const renderDeliveryTimeline = () => {
    const currentIdx = getActiveTimelineStepIndex();
    return (
      <div className="bg-white p-3 rounded-2xl border border-gray-150 space-y-2">
        <div className="flex justify-between items-center">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
            📍 Delivery Stage Status
          </span>
          <span className="text-[9px] bg-green-50 text-green-700 font-extrabold px-1.5 py-0.5 rounded-full uppercase">
            {activeTaskStep.replace(/_/g, ' ')}
          </span>
        </div>
        
        <div className="flex justify-between items-center relative px-1 pt-1">
          {/* Connector Line */}
          <div className="absolute left-3 right-3 top-4 h-[2px] bg-slate-100 -z-0"></div>
          {/* Active green filler */}
          <div 
            className="absolute left-3 top-4 h-[2.5px] bg-emerald-600 -z-0 transition-all duration-500"
            style={{ width: `${(currentIdx / 6) * 100}%` }}
          ></div>
          
          {progressTimelineSteps.map((item, idx) => {
            const isCompleted = idx < currentIdx;
            const isActive = idx === currentIdx;
            
            return (
              <div key={idx} className="flex flex-col items-center relative z-10">
                <div 
                  className={`h-6 w-6 rounded-full flex justify-center items-center text-[9px] font-black transition-all ${
                    isCompleted 
                      ? 'bg-emerald-600 text-white shadow-xs ring-4 ring-emerald-100' 
                      : isActive 
                        ? 'bg-orange-500 text-white shadow-md ring-4 ring-orange-100 scale-110 animate-pulse' 
                        : 'bg-white text-gray-400 border border-gray-200'
                  }`}
                  title={item.desc}
                >
                  {isCompleted ? '✓' : idx + 1}
                </div>
                <span className={`text-[8px] mt-1 font-extrabold tracking-tight text-center w-8 truncate ${
                  isActive ? 'text-orange-600 font-black' : isCompleted ? 'text-emerald-700' : 'text-gray-400'
                }`}>
                  {item.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // -----------------------------------------------------------------
  // Simulated Interactive Vector Map View
  // -----------------------------------------------------------------
  const renderSimulatedMap = (destination: 'restaurant' | 'ngo') => {
    return (
      <div className="h-36 bg-emerald-50 rounded-2xl border border-emerald-150 relative overflow-hidden flex flex-col justify-between p-2 shadow-inner">
        {/* Grid pattern background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(16,185,129,0.06)_1px,transparent_1px),linear-gradient(to_bottom,rgba(16,185,129,0.06)_1px,transparent_1px)] bg-[size:16px_16px]"></div>
        
        {/* Aesthetic styled waterbodies and parks */}
        <div className="absolute top-2 left-6 w-16 h-10 bg-blue-100 rounded-full blur-xs opacity-60"></div>
        <div className="absolute bottom-4 right-10 w-24 h-12 bg-green-100 rounded-full blur-xs opacity-70"></div>
        
        {/* Moving Route path lines */}
        <svg className="absolute inset-0 w-full h-full">
          <path 
            d={destination === 'restaurant' ? "M 30 110 C 60 70, 110 50, 240 40" : "M 240 40 C 180 50, 120 100, 40 100"} 
            fill="none" 
            stroke="#10B981" 
            strokeWidth="4.5" 
            strokeLinecap="round"
            strokeDasharray="8" 
            className="animate-dash" 
          />
        </svg>

        {/* GPS Active HUD overlay */}
        <div className="absolute top-1 right-2 bg-white/90 backdrop-blur-xs px-2 py-0.5 rounded-full text-[7px] font-black shadow-xs border border-green-200 text-green-700 flex items-center gap-1">
          <span className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse"></span>
          GPS: HIGH ACCURACY
        </div>

        {/* Start/Destination Node Marks */}
        {destination === 'restaurant' ? (
          <>
            {/* Volunteer start */}
            <div className="absolute left-6 bottom-4 text-center">
              <div className="h-7 w-7 bg-green-600 rounded-full flex justify-center items-center text-white text-xs shadow-md border-2 border-white animate-pulse">
                🏍️
              </div>
              <span className="text-[7px] font-extrabold text-green-800 bg-white px-1 py-0.5 rounded-md border border-gray-150 mt-1 block leading-none">You</span>
            </div>

            {/* Restaurant Dest */}
            <div className="absolute right-12 top-6 text-center">
              <div className="h-7 w-7 bg-orange-500 rounded-full flex justify-center items-center text-white text-xs shadow-md border-2 border-white">
                🏪
              </div>
              <span className="text-[7px] font-extrabold text-orange-700 bg-white px-1 py-0.5 rounded-md border border-gray-150 mt-1 block leading-none">ABC Restaurant</span>
            </div>
          </>
        ) : (
          <>
            {/* Volunteer at Rest */}
            <div className="absolute right-8 top-6 text-center">
              <div className="h-7 w-7 bg-orange-500 rounded-full flex justify-center items-center text-white text-xs shadow-md border-2 border-white">
                🏪
              </div>
              <span className="text-[7px] font-extrabold text-orange-700 bg-white px-1 py-0.5 rounded-md border border-gray-150 mt-1 block leading-none">ABC Restaurant</span>
            </div>

            {/* NGO Dest */}
            <div className="absolute left-6 bottom-4 text-center">
              <div className="h-7 w-7 bg-green-700 rounded-full flex justify-center items-center text-white text-xs shadow-md border-2 border-white animate-pulse">
                🏠
              </div>
              <span className="text-[7px] font-extrabold text-green-800 bg-white px-1 py-0.5 rounded-md border border-gray-150 mt-1 block leading-none">Helping Hands</span>
            </div>
          </>
        )}

        {/* Map Hud footer overlay */}
        <div className="bg-white/95 backdrop-blur-xs p-1.5 rounded-xl border border-gray-100 flex justify-between items-center text-3xs shadow-md relative z-10">
          <div className="flex items-center gap-1">
            <span className="text-base leading-none">📍</span>
            <div>
              <span className="font-extrabold text-gray-800 block leading-none">
                {destination === 'restaurant' ? 'Road No. 36, Jubilee Hills' : 'Banjara Hills, Hyderabad'}
              </span>
              <span className="text-gray-400 block text-[7px] mt-0.5">Estimated optimal food safety route</span>
            </div>
          </div>
          <div className="text-right bg-green-50 px-2 py-1 rounded-lg">
            <span className="font-black text-green-700 block text-[9px] leading-none">
              {destination === 'restaurant' ? '12 mins' : '15 mins'}
            </span>
            <span className="text-[8px] text-green-600 font-semibold block mt-0.5">
              {destination === 'restaurant' ? '1.8 km left' : '3.5 km left'}
            </span>
          </div>
        </div>
      </div>
    );
  };

  // Helper lists
  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-100 p-4" id="mobile-viewport-container">
      {/* 3D SMARTPHONE PREVIEW FRAME */}
      <div className="relative w-88 h-185 bg-black rounded-5xl shadow-2xl border-12 border-neutral-900 overflow-hidden flex flex-col select-none" id="simulated-device-frame">
        
        {/* Device camera notch and ear speaker */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 h-5 w-32 bg-neutral-900 rounded-b-xl z-50 flex justify-center items-center">
          <span className="h-1 w-8 bg-neutral-800 rounded-full"></span>
          <span className="h-2 w-2 bg-blue-950 rounded-full ml-2 border border-neutral-900"></span>
        </div>

        {/* Status bar */}
        <div className="bg-green-800 px-6 pt-6 pb-2 text-white flex justify-between items-center text-3xs font-bold z-40">
          <span>09:41 AM</span>
          <div className="flex items-center gap-1.5">
            <span>5G</span>
            <span className="h-2.5 w-4 bg-white/30 rounded-xxs border border-white relative flex items-center p-0.5">
              <span className="h-full w-2.5 bg-white rounded-xxs"></span>
            </span>
          </div>
        </div>

        {/* APP BODY CONTAINER */}
        <div className="flex-1 overflow-y-auto bg-gray-50 relative flex flex-col justify-between" id="app-body-scrollable">
          
          {/* HEADER BAR */}
          <div className="bg-gradient-to-r from-green-800 to-green-700 text-white p-4 flex justify-between items-center shadow-md">
            <div className="flex items-center gap-1.5">
              <Sparkles className="h-4.5 w-4.5 text-orange-400 animate-pulse" />
              <div>
                <span className="text-3xs text-green-200 uppercase font-black tracking-wider block leading-none">Akshaya Patra</span>
                <span className="text-xxs font-extrabold truncate w-40 block">{currentUser.orgName}</span>
              </div>
            </div>
            <span className="bg-orange-500 text-white text-3xs font-extrabold px-1.5 py-0.5 rounded-full uppercase tracking-wider">
              {currentUser.role}
            </span>
          </div>

          {/* ACTIVE PORTALS CONTENT */}
          <div className="flex-1 p-4 space-y-4 pb-20 overflow-y-auto">
            
            {/* ==========================================
                VOLUNTEER MOBILE APP SCREEN
               ========================================== */}
            {currentUser.role === 'volunteer' && (
              <>
                {/* 1. HOME TAB */}
                {activeTab === 'home' && (
                  <div className="space-y-4">
                    {/* Welcome Streak Card */}
                    <div className="bg-gradient-to-br from-green-700 to-green-900 text-white rounded-2xl p-4 shadow-sm relative overflow-hidden">
                      <div className="absolute right-[-10px] bottom-[-10px] text-white/5 font-black text-8xl">
                        {48 + sessionCompletedCount}
                      </div>
                      <span className="text-3xs text-green-200 block uppercase font-bold">Rider Dashboard • Active Session</span>
                      <h3 className="text-base font-black mt-1">Hello, {currentUser.name}!</h3>
                      <p className="text-xxs text-green-100 mt-1">Thank you for helping reduce food waste. Ready for another delivery?</p>
                      
                      <div className="flex gap-4 mt-3 pt-2 border-t border-white/10 text-center">
                        <div>
                          <span className="text-[8px] text-green-200 block uppercase font-extrabold">Total Completed</span>
                          <span className="text-sm font-extrabold">{48 + sessionCompletedCount} Deliveries</span>
                        </div>
                        <div>
                          <span className="text-[8px] text-green-200 block uppercase font-extrabold">Assigned Today</span>
                          <span className="text-sm font-extrabold">
                            {donations.filter(d => d.volunteerName === currentUser.name && d.status !== 'delivered').length} Active
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Active Pickup Section */}
                    <div>
                      <h4 className="font-black text-xs text-gray-800 uppercase tracking-wider mb-2">🚚 Active Assigned Pickup</h4>
                      
                      {donations.filter(d => d.volunteerName === currentUser.name && d.status !== 'delivered').length === 0 ? (
                        <div className="bg-white rounded-2xl p-6 text-center text-gray-400 border border-gray-150 shadow-xxs">
                          <CheckCircle className="h-8 w-8 mx-auto mb-1 opacity-50 text-emerald-600" />
                          <p className="text-xs font-bold text-gray-700">No active assigned pickups!</p>
                          <p className="text-3xs mt-1">NGO administrators will dispatch matches in real-time. Check back shortly.</p>
                        </div>
                      ) : (
                        donations.filter(d => d.volunteerName === currentUser.name && d.status !== 'delivered').map(donation => (
                          <div 
                            key={donation.id}
                            className="bg-white rounded-2xl border border-gray-200 shadow-xs p-4 space-y-3"
                          >
                            <div className="flex justify-between items-start">
                              <div>
                                <span className="bg-orange-100 text-orange-800 text-[8px] font-black px-1.5 py-0.5 rounded-full uppercase">
                                  {donation.status === 'assigned' ? 'RIDER ASSIGNED' : donation.status.toUpperCase()}
                                </span>
                                <h5 className="font-extrabold text-sm text-gray-900 mt-1">{donation.foodName}</h5>
                              </div>
                              <span className="text-xs font-black text-green-700 bg-green-50 px-2 py-1 rounded-xl">
                                {donation.quantity}
                              </span>
                            </div>

                            <div className="space-y-1.5 text-xxs border-t border-gray-100 pt-2.5 text-gray-600">
                              <div className="flex items-center gap-1.5">
                                <span className="text-xs">🏪</span>
                                <div>
                                  <span className="font-extrabold text-gray-800">Restaurant:</span> {donation.restaurantName}
                                </div>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <span className="text-xs">🏠</span>
                                <div>
                                  <span className="font-extrabold text-gray-800">NGO Destination:</span> {donation.ngoName || 'Helping Hands Foundation'}
                                </div>
                              </div>
                              <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-gray-50 text-[9px]">
                                <div>
                                  <span className="text-gray-400 block uppercase font-bold text-[7px]">Pickup Time</span>
                                  <span className="font-extrabold text-gray-800">2:30 PM</span>
                                </div>
                                <div>
                                  <span className="text-gray-400 block uppercase font-bold text-[7px]">Deadline</span>
                                  <span className="font-extrabold text-red-600">4:00 PM</span>
                                </div>
                              </div>
                              <div className="flex justify-between text-[9px] mt-1">
                                <div>
                                  <span className="text-gray-400 font-bold uppercase text-[7px] block">Distance</span>
                                  <span className="font-extrabold text-gray-800">{donation.distanceKm} km</span>
                                </div>
                                <div>
                                  <span className="text-gray-400 font-bold uppercase text-[7px] block">Special instruction</span>
                                  <span className="font-extrabold text-gray-800 truncate block w-32">{donation.specialInstructions}</span>
                                </div>
                              </div>
                            </div>

                            {/* Timeline tracker */}
                            {renderDeliveryTimeline()}

                            <div className="flex gap-2 pt-1 border-t border-gray-100">
                              <button
                                onClick={() => {
                                  setSelectedTask(donation);
                                  // Set to correct step based on status
                                  if (donation.status === 'assigned') {
                                    setActiveTaskStep('assigned');
                                  } else if (donation.status === 'picked_up') {
                                    setActiveTaskStep('picked_up');
                                  }
                                  setActiveTab('active_pickup');
                                }}
                                className="flex-1 bg-white border border-gray-200 text-gray-700 hover:bg-gray-50 font-extrabold py-2 px-3 rounded-xl text-xxs transition shadow-xxs flex items-center justify-center gap-1"
                              >
                                <Eye className="h-3 w-3 text-gray-500" /> View Details
                              </button>
                              
                              {activeTaskStep === 'assigned' && donation.status === 'assigned' && (
                                <button
                                  onClick={() => {
                                    setSelectedTask(donation);
                                    setActiveTaskStep('assigned');
                                    setActiveTab('active_pickup');
                                    onTriggerNotification?.('Pickup Imminent', 'Pickup starts in 30 minutes. Head to ABC Restaurant.', 'info');
                                  }}
                                  className="flex-1 bg-gradient-to-r from-green-700 to-green-600 text-white font-extrabold py-2 px-3 rounded-xl text-xxs transition shadow-xs flex items-center justify-center gap-1"
                                >
                                  <Play className="h-3 w-3 fill-white" /> Start Pickup
                                </button>
                              )}
                            </div>
                          </div>
                        ))
                      )}
                    </div>

                    {/* Upcoming Tasks Section */}
                    <div>
                      <h4 className="font-black text-xs text-gray-800 uppercase tracking-wider mb-2">📅 Other Available System Bookings</h4>
                      <div className="space-y-2">
                        {donations.filter(d => d.volunteerName !== currentUser.name && d.status === 'pending').slice(0, 2).map(task => (
                          <div key={task.id} className="bg-white p-3 rounded-xl border border-gray-150 flex justify-between items-center shadow-4xs">
                            <div>
                              <h5 className="font-extrabold text-xxs text-gray-800">{task.foodName}</h5>
                              <p className="text-[9px] text-gray-400">🏪 {task.restaurantName} • {task.distanceKm} km away</p>
                            </div>
                            <span className="text-[9px] font-black text-orange-600 bg-orange-50 px-2 py-0.5 rounded-md">
                              Claimable
                            </span>
                          </div>
                        ))}
                        <div className="bg-white/50 p-3 rounded-xl border border-dashed border-gray-200 text-center">
                          <p className="text-[9px] text-gray-500 font-medium">Automatic matching engine enabled ✓</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* 2. ACTIVE PICKUP WORKFLOW WIZARD (Tab active_pickup) */}
                {activeTab === 'active_pickup' && (
                  <div className="space-y-4">
                    {!selectedTask ? (
                      <div className="bg-white rounded-2xl p-6 text-center border border-gray-150">
                        <ClipboardList className="h-10 w-10 mx-auto text-gray-300 mb-2" />
                        <h4 className="font-bold text-xs text-gray-800">No Active Job Selected</h4>
                        <p className="text-3xs text-gray-500 mt-1">Please head over to the Home tab and click "Start Pickup" or "View Details" on your assigned task.</p>
                        <button
                          onClick={() => setActiveTab('home')}
                          className="mt-3 bg-green-700 text-white font-bold px-4 py-1.5 rounded-xl text-xxs shadow"
                        >
                          Go to Dashboard
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {/* Header for Active Job */}
                        <div className="flex justify-between items-center bg-white p-3 rounded-xl border border-gray-150">
                          <button
                            onClick={() => setActiveTab('home')}
                            className="text-xxs font-black text-gray-500 flex items-center gap-1 hover:underline"
                          >
                            <ArrowLeft className="h-3.5 w-3.5" /> Dashboard
                          </button>
                          <span className="text-3xs text-slate-400 font-extrabold uppercase">
                            ID: {selectedTask.id}
                          </span>
                        </div>

                        {/* Stage Progress Timeline Indicator */}
                        {renderDeliveryTimeline()}

                        {/* WIZARD SUB-SCREENS */}
                        
                        {/* SCREEN A: ASSIGNED/DETAILS VIEW */}
                        {activeTaskStep === 'assigned' && (
                          <div className="bg-white rounded-2xl border border-gray-150 p-4 space-y-3 shadow-xs">
                            <h4 className="font-black text-xs text-gray-800 uppercase tracking-wide border-b border-gray-100 pb-1.5">
                              📋 Pickup Details Screen
                            </h4>
                            
                            {/* Food Image Illustration */}
                            <div className="relative h-28 rounded-xl overflow-hidden shadow-inner border border-gray-100">
                              <img 
                                src="https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&q=80&w=600" 
                                alt={selectedTask.foodName} 
                                className="w-full h-full object-cover"
                                referrerPolicy="no-referrer"
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                              <div className="absolute bottom-2 left-2 text-white text-3xs font-extrabold flex items-center gap-1 bg-black/40 px-2 py-0.5 rounded-md backdrop-blur-xs">
                                <span>🍽️</span> {selectedTask.foodName} Registered Log
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-2 text-xxs">
                              <div className="col-span-2 bg-gradient-to-r from-orange-50 to-orange-100/50 p-3 rounded-xl border border-orange-100">
                                <span className="text-[8px] text-orange-800 font-black block uppercase">Surplus Package</span>
                                <span className="font-black text-gray-900 text-xs block mt-0.5">{selectedTask.foodName}</span>
                                <span className="text-3xs text-gray-500 mt-0.5 block font-medium">Qty: {selectedTask.quantity} • Prepared today</span>
                              </div>
                              
                              <div className="p-2 bg-gray-50 rounded-lg">
                                <span className="text-gray-400 block text-[7px] uppercase font-bold">Donor Restaurant</span>
                                <span className="font-extrabold text-gray-800 block text-[10px] mt-0.5">{selectedTask.restaurantName}</span>
                                <span className="text-[8px] text-gray-500 block">Jubilee Hills, Hyd</span>
                              </div>
                              
                              <div className="p-2 bg-gray-50 rounded-lg">
                                <span className="text-gray-400 block text-[7px] uppercase font-bold">Shelter NGO</span>
                                <span className="font-extrabold text-gray-800 block text-[10px] mt-0.5">{selectedTask.ngoName || 'Helping Hands Foundation'}</span>
                                <span className="text-[8px] text-gray-500 block">Banjara Hills, Hyd</span>
                              </div>
                            </div>

                            <div className="text-xxs space-y-2 bg-slate-50 p-3 rounded-xl text-gray-600 border border-slate-100">
                              <div>
                                <span className="font-extrabold text-slate-800 block">🏪 Restaurant Address</span>
                                <span className="text-slate-500 text-[10px] block mt-0.5">Road No. 36, Jubilee Hills, Hyderabad</span>
                              </div>
                              <div className="grid grid-cols-2 gap-2 pt-1.5 border-t border-slate-100">
                                <div>
                                  <span className="font-extrabold text-slate-800 block">👤 Contact Person</span>
                                  <span className="text-slate-500 text-[10px]">Amit Sharma</span>
                                </div>
                                <div>
                                  <span className="font-extrabold text-slate-800 block">📞 Phone</span>
                                  <span className="text-slate-500 text-[10px]">+91 98765 12345</span>
                                </div>
                              </div>
                              <div className="grid grid-cols-2 gap-2 pt-1.5 border-t border-slate-100">
                                <div>
                                  <span className="font-extrabold text-slate-800 block">⏳ Expiry Time</span>
                                  <span className="text-red-600 font-extrabold text-[10px]">{selectedTask.expiryTime}</span>
                                </div>
                                <div>
                                  <span className="font-extrabold text-slate-800 block">📏 Distance</span>
                                  <span className="text-slate-500 text-[10px]">{selectedTask.distanceKm} km</span>
                                </div>
                              </div>
                              <div className="pt-1.5 border-t border-slate-100">
                                <span className="font-extrabold text-slate-800 block">⚠️ Special Instructions</span>
                                <p className="text-slate-500 text-[10px] italic leading-tight mt-0.5">{selectedTask.specialInstructions}</p>
                              </div>
                            </div>

                            {/* Simulated Google Map location */}
                            {renderSimulatedMap('restaurant')}

                            <div className="grid grid-cols-2 gap-2 pt-2">
                              <button
                                onClick={() => triggerPhoneCall('Amit Sharma (ABC Restaurant)', '+91 98765 12345')}
                                className="bg-white border border-gray-200 text-gray-700 font-extrabold py-2 rounded-xl text-xxs hover:bg-gray-50 transition shadow-xxs flex items-center justify-center gap-1"
                              >
                                <Phone className="h-3 w-3 text-emerald-600" /> Call Restaurant
                              </button>
                              <button
                                onClick={() => {
                                  setActiveTaskStep('travelling_to_restaurant');
                                  onTriggerNotification?.('Pickup Route Active', 'Pickup starts in 30 minutes. Head to ABC Restaurant.', 'info');
                                }}
                                className="bg-green-700 text-white font-extrabold py-2 rounded-xl text-xxs hover:bg-green-800 transition shadow-xs flex items-center justify-center gap-1"
                              >
                                <Navigation className="h-3 w-3" /> Navigate to Store
                              </button>
                            </div>
                            
                            <button
                              onClick={() => {
                                setActiveTaskStep('reached_restaurant');
                                onTriggerNotification?.('Reached Restaurant', 'You have reached the restaurant. Proceed inside for verification.', 'success');
                              }}
                              className="w-full bg-orange-500 text-white font-black py-2 rounded-xl text-xxs hover:bg-orange-600 transition shadow-xs mt-1"
                            >
                              ✓ Already Reached Restaurant
                            </button>
                          </div>
                        )}

                        {/* SCREEN B: NAVIGATION TO RESTAURANT */}
                        {activeTaskStep === 'travelling_to_restaurant' && (
                          <div className="bg-white rounded-2xl border border-gray-150 p-4 space-y-3 shadow-xs">
                            <h4 className="font-black text-xs text-gray-800 uppercase tracking-wide border-b border-gray-100 pb-1.5">
                              🗺️ En Route to ABC Restaurant
                            </h4>

                            {renderSimulatedMap('restaurant')}

                            {/* Simulated Navigation Voice Text Card */}
                            <div className="bg-blue-50 border border-blue-150 p-3 rounded-xl flex items-start gap-2">
                              <Volume2 className="h-5 w-5 text-blue-600 shrink-0 mt-0.5 animate-bounce" />
                              <div className="text-xxs text-blue-800">
                                <span className="font-extrabold block">GPS VOICE ASSISTANCE ACTIVE</span>
                                <p className="mt-0.5 text-[10px] font-medium leading-snug">
                                  {gpsNavigating 
                                    ? '"Continue straight on Road No. 36 for 800 meters. The restaurant is on your left, next to Metro Pillar 12."' 
                                    : '"GPS ready. Click Start Navigation to initialize live telemetry and route updates."'}
                                </p>
                              </div>
                            </div>

                            <div className="flex gap-2 text-xxs">
                              <button
                                onClick={() => {
                                  setGpsNavigating(true);
                                  onTriggerNotification?.('Navigation Initialized', 'Voice assistance is routing via Jubilee Hills Road.', 'info');
                                }}
                                className="flex-1 bg-white border border-blue-200 text-blue-700 font-extrabold py-2.5 rounded-xl hover:bg-blue-50 transition shadow-xxs flex items-center justify-center gap-1"
                              >
                                <Play className="h-3 w-3 fill-blue-700" /> {gpsNavigating ? 'Navigating...' : 'Start Navigation'}
                              </button>
                              
                              <button
                                onClick={() => {
                                  onTriggerNotification?.('Route Refreshed', 'Recalculated route avoiding traffic near Metro station.', 'info');
                                  alert('Map route refreshed with active low-congestion road.');
                                }}
                                className="bg-gray-50 border border-gray-200 text-gray-600 font-extrabold p-2 rounded-xl hover:bg-gray-100 transition shadow-xxs"
                                title="Refresh Route"
                              >
                                <RefreshCw className="h-4.5 w-4.5 text-gray-500" />
                              </button>
                            </div>

                            <button
                              onClick={() => {
                                setActiveTaskStep('reached_restaurant');
                                onTriggerNotification?.('Reached Restaurant', 'You have arrived at the restaurant. Proceed inside for verification.', 'success');
                              }}
                              className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white font-black py-2.5 rounded-xl text-xxs hover:from-orange-600 hover:to-orange-700 transition shadow-md flex items-center justify-center gap-1"
                            >
                              📍 Reached Restaurant • Check-In
                            </button>
                          </div>
                        )}

                        {/* SCREEN C: FOOD PICKUP VERIFICATION (Food Safety Audit Checklist) */}
                        {activeTaskStep === 'reached_restaurant' && (
                          <div className="bg-white rounded-2xl border border-gray-150 p-4 space-y-3.5 shadow-xs">
                            <div className="border-b border-gray-100 pb-2">
                              <span className="text-[8px] font-black text-orange-600 block uppercase tracking-wider">Verification Audit</span>
                              <h4 className="font-black text-xs text-gray-800 uppercase tracking-wide">
                                🛡️ Food Pickup Verification
                              </h4>
                            </div>

                            <div className="bg-orange-50/50 p-2.5 rounded-xl border border-orange-100 text-xxs text-orange-800">
                              <p className="font-extrabold">Store: ABC Restaurant</p>
                              <p className="mt-0.5 text-[10px] text-orange-900 font-medium">Verify safety standards of the Vegetable Biryani package below.</p>
                            </div>

                            {/* Checklist parameters */}
                            <div className="space-y-2 bg-slate-50 p-3 rounded-xl border border-slate-100">
                              <span className="text-[8px] font-extrabold text-slate-400 uppercase block tracking-wider">Food Safety Checklist</span>
                              
                              <label className="flex items-start gap-2.5 text-xxs text-gray-700 font-semibold cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={volunteerSafetyChecklist.foodFresh}
                                  onChange={(e) => setVolunteerSafetyChecklist({ ...volunteerSafetyChecklist, foodFresh: e.target.checked })}
                                  className="mt-0.5 text-green-700 h-3.5 w-3.5 rounded border-gray-300 focus:ring-green-500"
                                />
                                <span>☑ Food is fresh & fragrant</span>
                              </label>

                              <label className="flex items-start gap-2.5 text-xxs text-gray-700 font-semibold cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={volunteerSafetyChecklist.properlyPacked}
                                  onChange={(e) => setVolunteerSafetyChecklist({ ...volunteerSafetyChecklist, properlyPacked: e.target.checked })}
                                  className="mt-0.5 text-green-700 h-3.5 w-3.5 rounded border-gray-300 focus:ring-green-500"
                                />
                                <span>☑ Properly packed in insulated thermal bags</span>
                              </label>

                              <label className="flex items-start gap-2.5 text-xxs text-gray-700 font-semibold cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={volunteerSafetyChecklist.sealedContainers}
                                  onChange={(e) => setVolunteerSafetyChecklist({ ...volunteerSafetyChecklist, sealedContainers: e.target.checked })}
                                  className="mt-0.5 text-green-700 h-3.5 w-3.5 rounded border-gray-300 focus:ring-green-500"
                                />
                                <span>☑ Sealed containers to prevent leakage</span>
                              </label>

                              <label className="flex items-start gap-2.5 text-xxs text-gray-700 font-semibold cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={volunteerSafetyChecklist.quantityVerified}
                                  onChange={(e) => setVolunteerSafetyChecklist({ ...volunteerSafetyChecklist, quantityVerified: e.target.checked })}
                                  className="mt-0.5 text-green-700 h-3.5 w-3.5 rounded border-gray-300 focus:ring-green-500"
                                />
                                <span>☑ Food quantity matches order (50 Meals count)</span>
                              </label>

                              <label className="flex items-start gap-2.5 text-xxs text-gray-700 font-semibold cursor-pointer">
                                <input
                                  type="checkbox"
                                  checked={volunteerSafetyChecklist.expiryConfirmed}
                                  onChange={(e) => setVolunteerSafetyChecklist({ ...volunteerSafetyChecklist, expiryConfirmed: e.target.checked })}
                                  className="mt-0.5 text-green-700 h-3.5 w-3.5 rounded border-gray-300 focus:ring-green-500"
                                />
                                <span>☑ Expiry time confirmed within safe limits</span>
                              </label>
                            </div>

                            {/* Camera & QR Placeholders */}
                            <div className="grid grid-cols-2 gap-2 text-xxs">
                              <button
                                onClick={() => captureMockPhoto('pickup')}
                                className={`py-2 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition ${
                                  pickupPhotoCaptured 
                                    ? 'bg-emerald-50 border-emerald-200 text-emerald-700' 
                                    : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                                }`}
                              >
                                <Camera className="h-4 w-4 text-slate-500" />
                                {pickupPhotoCaptured ? 'Photo Saved ✓' : 'Capture Photo'}
                              </button>

                              <button
                                onClick={() => scanMockQrCode('pickup')}
                                className={`py-2 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition ${
                                  pickupQrScanned 
                                    ? 'bg-emerald-50 border-emerald-200 text-emerald-700' 
                                    : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                                }`}
                              >
                                <QrCode className="h-4 w-4 text-slate-500" />
                                {pickupQrScanned ? 'Tag Verified ✓' : 'Scan QR Tag'}
                              </button>
                            </div>

                            {/* Confirmation Button */}
                            <button
                              onClick={() => {
                                const allChecked = Object.values(volunteerSafetyChecklist).every(Boolean);
                                if (!allChecked) {
                                  alert('Please review and check all food safety audit parameters first.');
                                  return;
                                }
                                onUpdateStatus(selectedTask.id, 'picked_up');
                                setActiveTaskStep('picked_up');
                                onTriggerNotification?.('Food Pickup Confirmed', 'Vegetable Biryani has been checked and verified. Dispatching to Helping Hands Foundation.', 'success');
                                onTriggerNotification?.('Route Dispatch', 'Deliver food to Helping Hands Foundation, Banjara Hills.', 'info');
                              }}
                              className={`w-full text-white font-black py-2.5 rounded-xl text-xxs shadow transition flex justify-center items-center gap-1 ${
                                Object.values(volunteerSafetyChecklist).every(Boolean)
                                  ? 'bg-emerald-600 hover:bg-emerald-700'
                                  : 'bg-slate-300 cursor-not-allowed opacity-75'
                              }`}
                            >
                              <ShieldCheck className="h-4 w-4" /> Confirm Food Pickup Completed
                            </button>
                          </div>
                        )}

                        {/* SCREEN D: TRANSIT NAVIGATION TO NGO */}
                        {activeTaskStep === 'picked_up' && (
                          <div className="bg-white rounded-2xl border border-gray-150 p-4 space-y-3 shadow-xs">
                            <h4 className="font-black text-xs text-gray-800 uppercase tracking-wide border-b border-gray-100 pb-1.5">
                              🗺️ Transit: Deliver to NGO
                            </h4>

                            {renderSimulatedMap('ngo')}

                            <div className="bg-gradient-to-r from-emerald-50 to-emerald-100/50 p-3 rounded-xl border border-emerald-100 space-y-2">
                              <p className="font-extrabold flex items-center gap-1 text-emerald-800 text-xxs">
                                <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                                Delivering: {selectedTask.foodName}
                              </p>
                              
                              <div className="text-3xs text-emerald-900 font-semibold space-y-1 bg-white/60 p-2 rounded-lg border border-emerald-100/30">
                                <div>🏠 <span className="font-bold">NGO Name:</span> Helping Hands Foundation</div>
                                <div>📍 <span className="font-bold">Address:</span> Banjara Hills, Hyderabad</div>
                                <div>👤 <span className="font-bold">Contact Person:</span> Saraswathi Devi</div>
                                <div>📞 <span className="font-bold">Phone Number:</span> +91 94412 34567</div>
                              </div>
                            </div>

                            {/* Simulated Navigation Voice Text Card */}
                            <div className="bg-blue-50 border border-blue-150 p-3 rounded-xl flex items-start gap-2">
                              <Volume2 className="h-5 w-5 text-blue-600 shrink-0 mt-0.5 animate-bounce" />
                              <div className="text-xxs text-blue-800">
                                <span className="font-extrabold block">GPS NGO VOICE NAVIGATION ACTIVE</span>
                                <p className="mt-0.5 text-[10px] font-medium leading-snug">
                                  {gpsNavigating 
                                    ? '"Turn right onto Banjara Hills Road. The NGO shelter is 400 meters ahead, past the community park."' 
                                    : '"GPS ready. Click Start Navigation to activate voice routing directions to Helping Hands NGO."'}
                                </p>
                              </div>
                            </div>

                            <div className="flex gap-2 text-xxs">
                              <button
                                onClick={() => {
                                  setGpsNavigating(true);
                                  onTriggerNotification?.('Navigation Initialized', 'Voice assistance is routing via Banjara Hills Main Road.', 'info');
                                }}
                                className="flex-1 bg-white border border-blue-200 text-blue-700 font-extrabold py-2 rounded-xl hover:bg-blue-50 transition shadow-xxs flex items-center justify-center gap-1"
                              >
                                <Play className="h-3 w-3 fill-blue-700" /> {gpsNavigating ? 'Navigating...' : 'Start Navigation'}
                              </button>
                              
                              <button
                                onClick={() => triggerPhoneCall('Saraswathi Devi (Helping Hands Foundation)', '+91 94412 34567')}
                                className="bg-white border border-gray-200 text-gray-700 font-extrabold py-2 px-3 rounded-xl hover:bg-gray-50 transition shadow-xxs flex items-center justify-center"
                                title="Call NGO Recipient"
                              >
                                <Phone className="h-4.5 w-4.5 text-emerald-600" />
                              </button>
                            </div>

                            <button
                              onClick={() => {
                                setActiveTaskStep('reached_ngo');
                                onTriggerNotification?.('Reached NGO', 'You have arrived at the NGO shelter. Please initiate verification.', 'success');
                              }}
                              className="w-full bg-gradient-to-r from-green-700 to-green-600 text-white font-black py-2.5 rounded-xl text-xxs hover:from-green-800 hover:to-green-700 transition shadow-md flex justify-center items-center gap-1"
                            >
                              📍 Arrived at NGO • Check-In
                            </button>
                          </div>
                        )}

                        {/* SCREEN E: DELIVERY CONFIRMATION & DIGITAL SIGNATURE */}
                        {activeTaskStep === 'reached_ngo' && (
                          <div className="bg-white rounded-2xl border border-gray-150 p-4 space-y-3 shadow-xs">
                            <h4 className="font-black text-xs text-gray-800 uppercase tracking-wide border-b border-gray-100 pb-1.5">
                              ✍️ Delivery Confirmation Screen
                            </h4>

                            <div className="space-y-1 bg-gray-50 p-3 rounded-xl text-xxs">
                              <div><span className="font-extrabold text-gray-800">NGO Representative:</span> Helping Hands Foundation</div>
                              <div><span className="font-extrabold text-gray-800">Delivered Content:</span> Vegetable Biryani ({selectedTask.quantity})</div>
                              <div><span className="font-extrabold text-gray-800">Delivery Timestamp:</span> {new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit', second: '2-digit'})} (Live synchronized)</div>
                            </div>

                            {/* Digital signature canvas pad */}
                            <div className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                              <div className="flex justify-between items-center text-[8px] font-extrabold text-slate-400 uppercase tracking-wider">
                                <span>✍️ Collect Digital Signature</span>
                                <button onClick={clearCanvas} className="text-orange-600 hover:underline">Clear Canvas</button>
                              </div>
                              
                              {/* Canvas frame */}
                              <div className="border border-slate-200 rounded-lg bg-white overflow-hidden">
                                <canvas
                                  ref={canvasRef}
                                  width={280}
                                  height={88}
                                  onMouseDown={startDrawing}
                                  onMouseMove={draw}
                                  onMouseUp={stopDrawing}
                                  onMouseLeave={stopDrawing}
                                  onTouchStart={startDrawing}
                                  onTouchMove={draw}
                                  onTouchEnd={stopDrawing}
                                  className="w-full bg-white cursor-crosshair block touch-none"
                                />
                              </div>
                              <span className="text-[7px] text-slate-400 text-center block font-medium mt-0.5">
                                Ask NGO Manager to sign inside box using mouse or touch
                              </span>
                            </div>

                            {/* Photo & Scan Verification row */}
                            <div className="grid grid-cols-2 gap-2 text-xxs">
                              <button
                                onClick={() => captureMockPhoto('delivery')}
                                className={`py-2 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition ${
                                  deliveryPhotoCaptured 
                                    ? 'bg-emerald-50 border-emerald-200 text-emerald-700' 
                                    : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                                }`}
                              >
                                <Camera className="h-4 w-4 text-slate-500" />
                                {deliveryPhotoCaptured ? 'Photo Saved ✓' : 'Capture Photo'}
                              </button>

                              <button
                                onClick={() => scanMockQrCode('delivery')}
                                className={`py-2 rounded-xl border font-bold flex items-center justify-center gap-1.5 transition ${
                                  deliveryQrScanned 
                                    ? 'bg-emerald-50 border-emerald-200 text-emerald-700' 
                                    : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                                }`}
                              >
                                <QrCode className="h-4 w-4 text-slate-500" />
                                {deliveryQrScanned ? 'Shelter QR Verified ✓' : 'Scan NGO QR'}
                              </button>
                            </div>

                            <button
                              onClick={() => {
                                if (!hasSigned) {
                                  alert('NGO Manager signature is required to complete delivery.');
                                  return;
                                }
                                onUpdateStatus(selectedTask.id, 'delivered');
                                setSessionCompletedCount(prev => prev + 1);
                                setActiveTaskStep('success');
                                onTriggerNotification?.('Delivery completed successfully', '50 meals of Vegetable Biryani successfully transferred to Helping Hands Foundation.', 'success');
                                onTriggerNotification?.('Thank you for volunteering', 'Thank you for volunteering! Your direct action feeds families in need.', 'success');
                              }}
                              className={`w-full text-white font-black py-2.5 rounded-xl text-xxs shadow transition ${
                                hasSigned 
                                  ? 'bg-emerald-600 hover:bg-emerald-700' 
                                  : 'bg-slate-300 cursor-not-allowed opacity-75'
                              }`}
                            >
                              ✓ Complete Delivery
                            </button>
                          </div>
                        )}

                        {/* SCREEN F: DELIVERY SUCCESS SCREEN */}
                        {activeTaskStep === 'success' && (
                          <div className="bg-white rounded-2xl border border-gray-150 p-5 space-y-4 shadow-md text-center">
                            <div className="inline-flex h-12 w-12 bg-emerald-100 text-emerald-700 rounded-full justify-center items-center text-xl shadow-xs animate-bounce">
                              🎉
                            </div>
                            
                            <div>
                              <h4 className="font-black text-sm text-gray-900">🎉 Delivery Completed Successfully!</h4>
                              <p className="text-xxs text-gray-500 mt-1">Thank you for volunteering, your effort directly feeds families in need.</p>
                            </div>

                            {/* Impact Stats Grid */}
                            <div className="bg-emerald-50/50 p-3 rounded-2xl border border-emerald-100 text-left space-y-2.5">
                              <span className="text-[8px] font-black text-emerald-800 uppercase tracking-widest block text-center border-b border-emerald-100 pb-1">
                                🌸 Ecological Impact Stats
                              </span>
                              
                              <div className="grid grid-cols-2 gap-3.5 text-center">
                                <div className="p-1.5 bg-white rounded-xl border border-emerald-100">
                                  <span className="text-[14px] font-black text-emerald-700 block leading-none">50</span>
                                  <span className="text-[7px] text-gray-400 font-extrabold uppercase mt-1 block">Meals Delivered</span>
                                </div>
                                <div className="p-1.5 bg-white rounded-xl border border-emerald-100">
                                  <span className="text-[14px] font-black text-emerald-700 block leading-none">12</span>
                                  <span className="text-[7px] text-gray-400 font-extrabold uppercase mt-1 block">Families Helped</span>
                                </div>
                                <div className="p-1.5 bg-white rounded-xl border border-emerald-100">
                                  <span className="text-[14px] font-black text-emerald-700 block leading-none">20 kg</span>
                                  <span className="text-[7px] text-gray-400 font-extrabold uppercase mt-1 block">Food Saved</span>
                                </div>
                                <div className="p-1.5 bg-white rounded-xl border border-emerald-100">
                                  <span className="text-[14px] font-black text-emerald-700 block leading-none">38 kg</span>
                                  <span className="text-[7px] text-gray-400 font-extrabold uppercase mt-1 block">CO₂ Reduced</span>
                                </div>
                              </div>
                            </div>

                            <div className="flex gap-2 text-xxs">
                              <button
                                onClick={() => {
                                  setSelectedTask(null);
                                  setActiveTaskStep('assigned');
                                  setActiveTab('history');
                                }}
                                className="flex-1 bg-white border border-gray-200 text-gray-700 font-extrabold py-2 rounded-xl hover:bg-gray-50 shadow-xxs"
                              >
                                View History
                              </button>
                              
                              <button
                                onClick={() => {
                                  setSelectedTask(null);
                                  setActiveTaskStep('assigned');
                                  setActiveTab('home');
                                }}
                                className="flex-1 bg-green-700 hover:bg-green-800 text-white font-extrabold py-2 rounded-xl shadow-xs"
                              >
                                Back to Dashboard
                              </button>
                            </div>
                          </div>
                        )}

                      </div>
                    )}
                  </div>
                )}

                {/* 3. HISTORY TAB */}
                {activeTab === 'history' && (
                  <div className="space-y-4">
                    <h4 className="font-black text-xs text-gray-800 uppercase tracking-wider">📜 Completed Deliveries</h4>
                    
                    {donations.filter(d => d.volunteerName === currentUser.name && d.status === 'delivered').length === 0 ? (
                      <div className="bg-white rounded-2xl p-6 text-center text-gray-400 border border-gray-150 shadow-xxs">
                        <History className="h-8 w-8 mx-auto mb-1 opacity-50" />
                        <p className="text-xs font-bold text-gray-700">No deliveries completed yet.</p>
                        <p className="text-3xs mt-1">Your delivered listings will archive here securely.</p>
                      </div>
                    ) : (
                      <div className="space-y-3.5">
                        {donations.filter(d => d.volunteerName === currentUser.name && d.status === 'delivered').map(donation => (
                          <div key={donation.id} className="bg-white rounded-2xl border border-gray-150 p-3.5 shadow-4xs space-y-2">
                            <div className="flex justify-between items-start">
                              <div>
                                <h5 className="font-extrabold text-xs text-gray-900">{donation.foodName}</h5>
                                <p className="text-[9px] text-emerald-700 font-bold">🏪 {donation.restaurantName}</p>
                              </div>
                              <span className="bg-emerald-50 text-emerald-700 text-[8px] font-black px-2 py-0.5 rounded-full uppercase">
                                Delivered
                              </span>
                            </div>

                            <div className="bg-slate-50 p-2 rounded-xl text-3xs text-gray-500 space-y-1">
                              <div><span className="font-extrabold text-gray-700">Recipient Shelter:</span> {donation.ngoName || 'Helping Hands Foundation'}</div>
                              <div><span className="font-extrabold text-gray-700">Quantity Served:</span> {donation.quantity}</div>
                              <div><span className="font-extrabold text-gray-700">Ecological CO₂ reduction:</span> {Math.round(donation.estMealsServed * 0.76)} kg CO₂</div>
                            </div>

                            <div className="flex justify-between items-center text-3xs text-gray-400 mt-1">
                              <span>📅 Completed Today</span>
                              <button 
                                onClick={() => {
                                  setSelectedTask(donation);
                                  setActiveTaskStep('success');
                                  setActiveTab('active_pickup');
                                }}
                                className="text-green-700 hover:underline font-extrabold"
                              >
                                View Impact Stats →
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </>
            )}

            {/* ==========================================
                RESTAURANT MOBILE APP SCREEN
               ========================================== */}
            {currentUser.role === 'donor' && (
              <>
                {activeTab === 'home' && (
                  <div className="space-y-4">
                    {/* Fast Donate Mobile Card Banner */}
                    <div className="bg-gradient-to-br from-green-800 to-green-950 text-white p-5 rounded-2xl shadow-md text-center">
                      <h3 className="text-base font-black">Food Waste Reduction</h3>
                      <p className="text-xxs text-green-200 mt-0.5 max-w-xs mx-auto">Connecting ABC Restaurant to local hunger programs.</p>
                      
                      <button
                        onClick={() => setShowDonateForm(true)}
                        className="mt-3 bg-orange-500 hover:bg-orange-600 text-white font-extrabold py-2 px-5 rounded-xl text-xxs transition shadow-sm"
                      >
                        ➕ Create Food Listing
                      </button>
                    </div>

                    {showDonateForm ? (
                      <form onSubmit={handleDonateSubmit} className="bg-white p-4 rounded-2xl border border-gray-150 space-y-3.5">
                        <div className="flex justify-between items-center border-b border-gray-100 pb-2">
                          <span className="text-xs font-bold text-gray-800">Donate Surplus</span>
                          <button onClick={() => setShowDonateForm(false)} className="text-3xs text-gray-400 hover:underline">Cancel</button>
                        </div>

                        <div>
                          <label className="block text-3xs font-bold text-gray-500 mb-0.5">Food Name</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. Mixed Veg Pulav"
                            value={foodName}
                            onChange={(e) => setFoodName(e.target.value)}
                            className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xxs"
                          />
                        </div>

                        <div>
                          <label className="block text-3xs font-bold text-gray-500 mb-0.5">Quantity</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. 50 Meals"
                            value={quantity}
                            onChange={(e) => setQuantity(e.target.value)}
                            className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xxs"
                          />
                        </div>

                        <div>
                          <label className="block text-3xs font-bold text-gray-500 mb-0.5">Expiry</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. 5:00 PM"
                            value={expiryTime}
                            onChange={(e) => setExpiryTime(e.target.value)}
                            className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xxs"
                          />
                        </div>

                        <div>
                          <label className="block text-3xs font-bold text-gray-500 mb-0.5">Pickup Address</label>
                          <input
                            type="text"
                            required
                            placeholder="Address"
                            value={pickupAddress}
                            onChange={(e) => setPickupAddress(e.target.value)}
                            className="w-full px-3 py-2 rounded-lg border border-gray-200 text-xxs"
                          />
                        </div>

                        <button
                          type="submit"
                          className="w-full bg-green-700 text-white font-bold py-2 rounded-xl text-xxs shadow-xs"
                        >
                          Submit to Live Database
                        </button>
                      </form>
                    ) : (
                      <div className="space-y-3">
                        <h4 className="font-extrabold text-xs text-gray-800 uppercase tracking-wider">Active Food Listings</h4>
                        {donations.filter(d => d.restaurantName === currentUser.orgName).map(donation => (
                          <div key={donation.id} className="bg-white p-3.5 rounded-2xl border border-gray-150 shadow-xxs space-y-2">
                            <div className="flex justify-between items-start">
                              <h5 className="font-bold text-xs text-gray-900">{donation.foodName}</h5>
                              <span className="text-3xs font-bold uppercase bg-orange-500 text-white px-1.5 py-0.5 rounded">
                                {donation.status}
                              </span>
                            </div>
                            <div className="text-3xs text-gray-400">
                              Qty: {donation.quantity} • Expiry: {donation.expiryTime}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </>
            )}

            {/* ==========================================
                NGO MOBILE APP SCREEN
               ========================================== */}
            {currentUser.role === 'ngo' && (
              <>
                {activeTab === 'home' && (
                  <div className="space-y-4">
                    <h4 className="font-extrabold text-xs text-gray-800 uppercase tracking-wider">⚠️ Available Nearby Food</h4>
                    
                    {donations.filter(d => d.status === 'pending').map(donation => (
                      <div key={donation.id} className="bg-white p-3.5 rounded-2xl border border-gray-150 shadow-xxs space-y-3">
                        <div>
                          <span className="text-3xs text-orange-600 font-bold block">{donation.restaurantName}</span>
                          <h5 className="font-bold text-xs text-gray-900">{donation.foodName}</h5>
                          <p className="text-3xs text-gray-400">📍 {donation.location} ({donation.distanceKm} km away)</p>
                        </div>

                        <div className="bg-gray-50 p-2 rounded-lg grid grid-cols-2 gap-2 text-3xs">
                          <div><span className="text-gray-400">Qty:</span> {donation.quantity}</div>
                          <div><span className="text-gray-400">Expiry:</span> {donation.expiryTime}</div>
                        </div>

                        <button
                          onClick={() => setShowSafetyChecklist(donation)}
                          className="w-full bg-green-700 hover:bg-green-800 text-white font-bold py-2 rounded-xl text-xxs shadow-xxs transition"
                        >
                          Claim and Schedule Pickup
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}

            {/* ==========================================
                COMMON APP VIEW: NOTIFICATIONS TAB
               ========================================== */}
            {activeTab === 'notifications' && (
              <div className="space-y-3">
                <h4 className="font-extrabold text-xs text-gray-800 uppercase tracking-wider">Live System Alerts</h4>
                {notifications.length === 0 ? (
                  <div className="bg-white p-6 rounded-2xl border border-gray-150 text-center text-gray-400 text-xxs">
                    No active messages right now.
                  </div>
                ) : (
                  notifications.map(n => (
                    <div key={n.id} className="p-3 bg-white rounded-2xl border border-gray-150 shadow-xxs flex gap-2.5 items-start">
                      <div className={`p-1.5 rounded-lg text-xs mt-0.5 ${
                        n.type === 'success' ? 'bg-emerald-50 text-emerald-700' :
                        n.type === 'warning' ? 'bg-orange-50 text-orange-700' : 'bg-green-50 text-green-700'
                      }`}>
                        🔔
                      </div>
                      <div>
                        <h5 className="font-bold text-xs text-gray-900 leading-snug">{n.title}</h5>
                        <p className="text-3xs text-gray-500 mt-0.5 leading-relaxed">{n.message}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* ==========================================
                COMMON APP VIEW: PROFILE TAB
               ========================================== */}
            {activeTab === 'profile' && (
              <div className="space-y-4 text-center">
                <div className="inline-flex h-16 w-16 bg-gradient-to-tr from-green-800 to-emerald-600 text-white rounded-full font-black text-2xl justify-center items-center shadow-md border-4 border-white">
                  {currentUser.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-extrabold text-sm text-gray-900">{currentUser.name}</h4>
                  <p className="text-xxs text-gray-500">{currentUser.email}</p>
                  <p className="text-xxs font-bold text-orange-600 mt-0.5">Role: {currentUser.role.toUpperCase()} • {currentUser.orgName}</p>
                </div>

                <div className="bg-white rounded-2xl p-4 border border-gray-150 text-left space-y-3 shadow-xxs">
                  <h5 className="text-xxs font-extrabold uppercase text-gray-400">Account Parameters</h5>
                  <div className="space-y-2 text-xxs">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Device Platform</span>
                      <span className="font-semibold text-gray-800">Simulated Android Core v14</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Firebase Synchronization</span>
                      <span className="font-bold text-green-700 flex items-center gap-1">🟢 Cloud Active</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Haptic/Audio Feedback</span>
                      <span className="font-semibold text-gray-800">Enabled</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={onLogout}
                  className="w-full bg-rose-50 border border-rose-200 text-rose-700 hover:bg-rose-100 font-extrabold py-2 rounded-xl text-xxs transition shadow-4xs"
                >
                  Log Out of Session
                </button>
              </div>
            )}

          </div>

          {/* BOTTOM NAVIGATION TAB BAR */}
          <nav className="absolute bottom-0 left-0 right-0 bg-white border-t border-gray-150 py-2 px-1 flex justify-between items-center z-50">
            {currentUser.role === 'volunteer' ? (
              <>
                <button 
                  onClick={() => { setActiveTab('home'); setSelectedTask(null); }}
                  className={`flex flex-col items-center gap-0.5 flex-1 transition ${activeTab === 'home' ? 'text-green-700 font-extrabold' : 'text-gray-400 font-normal'}`}
                >
                  <Home className="h-4.5 w-4.5" />
                  <span className="text-[8px] font-black uppercase">Home</span>
                </button>
                <button 
                  onClick={() => {
                    // Pre-select active assigned pickup if available
                    const activeAssigned = donations.find(d => d.volunteerName === currentUser.name && d.status !== 'delivered');
                    if (activeAssigned && !selectedTask) {
                      setSelectedTask(activeAssigned);
                      if (activeAssigned.status === 'assigned') {
                        setActiveTaskStep('assigned');
                      } else if (activeAssigned.status === 'picked_up') {
                        setActiveTaskStep('picked_up');
                      }
                    }
                    setActiveTab('active_pickup');
                  }}
                  className={`flex flex-col items-center gap-0.5 flex-1 transition ${activeTab === 'active_pickup' ? 'text-green-700 font-extrabold' : 'text-gray-400 font-normal'}`}
                >
                  <ClipboardList className="h-4.5 w-4.5" />
                  <span className="text-[8px] font-black uppercase">Active Pickup</span>
                </button>
                <button 
                  onClick={() => setActiveTab('history')}
                  className={`flex flex-col items-center gap-0.5 flex-1 transition ${activeTab === 'history' ? 'text-green-700 font-extrabold' : 'text-gray-400 font-normal'}`}
                >
                  <History className="h-4.5 w-4.5" />
                  <span className="text-[8px] font-black uppercase">History</span>
                </button>
                <button 
                  onClick={() => setActiveTab('notifications')}
                  className={`flex flex-col items-center gap-0.5 flex-1 relative transition ${activeTab === 'notifications' ? 'text-green-700 font-extrabold' : 'text-gray-400 font-normal'}`}
                >
                  <Bell className="h-4.5 w-4.5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-0 right-5 h-1.5 w-1.5 rounded-full bg-orange-500 ring-1 ring-white"></span>
                  )}
                  <span className="text-[8px] font-black uppercase">Alerts</span>
                </button>
                <button 
                  onClick={() => setActiveTab('profile')}
                  className={`flex flex-col items-center gap-0.5 flex-1 transition ${activeTab === 'profile' ? 'text-green-700' : 'text-gray-400'}`}
                >
                  <User className="h-4.5 w-4.5" />
                  <span className="text-[8px] font-black uppercase">Profile</span>
                </button>
              </>
            ) : (
              <>
                <button 
                  onClick={() => { setActiveTab('home'); setSelectedTask(null); }}
                  className={`flex flex-col items-center gap-1 flex-1 transition ${activeTab === 'home' ? 'text-green-700' : 'text-gray-400'}`}
                >
                  <Home className="h-4.5 w-4.5" />
                  <span className="text-4xs font-black uppercase">HOME</span>
                </button>
                <button 
                  onClick={() => setActiveTab('notifications')}
                  className={`flex flex-col items-center gap-1 flex-1 relative transition ${activeTab === 'notifications' ? 'text-green-700' : 'text-gray-400'}`}
                >
                  <Bell className="h-4.5 w-4.5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-0 right-6 h-2 w-2 rounded-full bg-orange-500 ring-2 ring-white"></span>
                  )}
                  <span className="text-4xs font-black uppercase">ALERTS</span>
                </button>
                <button 
                  onClick={() => setActiveTab('profile')}
                  className={`flex flex-col items-center gap-1 flex-1 transition ${activeTab === 'profile' ? 'text-green-700' : 'text-gray-400'}`}
                >
                  <User className="h-4.5 w-4.5" />
                  <span className="text-4xs font-black uppercase">PROFILE</span>
                </button>
              </>
            )}
          </nav>

        </div>

        {/* Home Indicator bar of iPhone/Android simulator */}
        <div className="bg-white pb-2 flex justify-center items-center z-40">
          <span className="h-1 w-28 bg-neutral-300 rounded-full"></span>
        </div>

      </div>

      {/* MOBILE FOOD SAFETY MODAL FOR NGO CLAIM */}
      {showSafetyChecklist && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-[60]">
          <div className="bg-white rounded-3xl p-5 max-w-sm w-full space-y-4">
            <div className="text-center">
              <span className="text-xl">🛡️</span>
              <h4 className="font-extrabold text-sm text-gray-900 mt-1">Safety Clearance Audit</h4>
              <p className="text-3xs text-gray-500">Confirm parameters below before claim is dispatched.</p>
            </div>

            <div className="space-y-3.5 bg-gray-50 p-3 rounded-xl text-xxs">
              <label className="flex items-start gap-2 text-gray-700 font-semibold">
                <input
                  type="checkbox"
                  checked={safetyChecklist.freshFood}
                  onChange={(e) => setSafetyChecklist({ ...safetyChecklist, freshFood: e.target.checked })}
                  className="mt-0.5 text-green-700"
                />
                <span>Passes Fresh Smell and Visual Inspection</span>
              </label>
              <label className="flex items-start gap-2 text-gray-700 font-semibold">
                <input
                  type="checkbox"
                  checked={safetyChecklist.properPackaging}
                  onChange={(e) => setSafetyChecklist({ ...safetyChecklist, properPackaging: e.target.checked })}
                  className="mt-0.5 text-green-700"
                />
                <span>Proper thermal or leak-proof packaging</span>
              </label>
              <label className="flex items-start gap-2 text-gray-700 font-semibold">
                <input
                  type="checkbox"
                  checked={safetyChecklist.safeTemperature}
                  onChange={(e) => setSafetyChecklist({ ...safetyChecklist, safeTemperature: e.target.checked })}
                  className="mt-0.5 text-green-700"
                />
                <span>Safe holding temperature verified</span>
              </label>
            </div>

            <div className="flex gap-2 text-xxs">
              <button
                onClick={handleSafetyAccept}
                className="flex-1 bg-green-700 text-white font-bold py-2 rounded-xl"
              >
                Clear & Continue
              </button>
              <button
                onClick={() => setShowSafetyChecklist(null)}
                className="px-4 bg-gray-100 text-gray-600 rounded-xl font-bold"
              >
                Back
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
