import React, { useState } from 'react';
import { Donation, AppNotification, LeaderboardItem, Volunteer, UserRole } from '../types';
import foodCareLogo from '../assets/images/food_care_logo_1783153548837.jpg';
import { 
  LayoutDashboard, PlusCircle, History, BarChart3, Award, Settings, LogOut, 
  User, CheckCircle2, ChevronRight, Sparkles, MapPin, Calendar, Clock, AlertCircle, 
  TrendingUp, Leaf, Droplet, UserCheck, ShieldAlert, Check, HelpCircle, ArrowRight,
  ChevronDown, Send, FileSpreadsheet, FileText, Ban, Trash2, ShieldCheck, Heart
} from 'lucide-react';
import { AIRecommendations, AIPredictiveTrends } from './AIRecommendations';

interface WebViewProps {
  donations: Donation[];
  volunteers: Volunteer[];
  notifications: AppNotification[];
  leaderboard: LeaderboardItem[];
  currentUser: { name: string; orgName: string; email: string; phone: string; role: UserRole };
  onLogout: () => void;
  onAddDonation: (donation: Omit<Donation, 'id' | 'createdAt' | 'restaurantName' | 'ngoName' | 'volunteerName' | 'volunteerPhone' | 'assignedAt' | 'pickedUpAt' | 'deliveredAt' | 'priorityScore' | 'expiryRisk' | 'estMealsServed' | 'smartMatches'>) => void;
  onAcceptDonation: (id: string, ngoName: string) => void;
  onAssignVolunteer: (id: string, volunteerId: string) => void;
  onUpdateStatus: (id: string, status: Donation['status']) => void;
  onTriggerNotification: (title: string, message: string, type: AppNotification['type']) => void;
  onAddAnnouncement: (msg: string) => void;
  onApprovePartner: (name: string) => void;
}

export const WebView: React.FC<WebViewProps> = ({
  donations,
  volunteers,
  notifications,
  leaderboard,
  currentUser,
  onLogout,
  onAddDonation,
  onAcceptDonation,
  onAssignVolunteer,
  onUpdateStatus,
  onTriggerNotification,
  onAddAnnouncement,
  onApprovePartner,
}) => {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchText, setSearchText] = useState<string>('');

  // Form states for Donate Food
  const [foodName, setFoodName] = useState('');
  const [category, setCategory] = useState('Main Course');
  const [vegNonVeg, setVegNonVeg] = useState<'Veg' | 'Non-Veg'>('Veg');
  const [quantity, setQuantity] = useState('');
  const [prepTime, setPrepTime] = useState('12:00 PM');
  const [expiryTime, setExpiryTime] = useState('5:00 PM');
  const [pickupAddress, setPickupAddress] = useState('');
  const [location, setLocation] = useState('Madhapur, Hyderabad');
  const [condition, setCondition] = useState('Freshly prepared');
  const [specialInstructions, setSpecialInstructions] = useState('');
  const [donationSuccess, setDonationSuccess] = useState(false);
  const [latestSubmittedDonation, setLatestSubmittedDonation] = useState<Donation | null>(null);

  // NGO Accept / Food Safety States
  const [selectedDonationForSafety, setSelectedDonationForSafety] = useState<Donation | null>(null);
  const [safetyChecklist, setSafetyChecklist] = useState({
    freshFood: false,
    properPackaging: false,
    safeTemperature: false,
    cleanContainers: false,
    withinExpiry: false
  });
  
  // Volunteer allocation state
  const [selectedDonationForVolunteer, setSelectedDonationForVolunteer] = useState<Donation | null>(null);
  const [selectedVolunteerId, setSelectedVolunteerId] = useState<string>('');

  // Admin states
  const [announcementText, setAnnouncementText] = useState('');
  const [pendingApprovals, setPendingApprovals] = useState([
    { name: 'Golkonda Pavilion Restaurant', type: 'Donor', address: 'Banjara Hills', appliedAt: '2026-07-03' },
    { name: 'Sankalp Shelter NGO', type: 'Receiver', address: 'Begumpet', appliedAt: '2026-07-02' }
  ]);

  // Handle Form Submit
  const handleDonateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!foodName || !quantity || !pickupAddress) {
      alert('Please fill out all mandatory fields.');
      return;
    }

    onAddDonation({
      foodName,
      category,
      vegNonVeg,
      quantity,
      prepTime,
      expiryTime,
      pickupAddress,
      location,
      condition,
      specialInstructions,
      distanceKm: parseFloat((Math.random() * 4 + 1).toFixed(1)),
    });

    // Reset Form
    setFoodName('');
    setQuantity('');
    setPickupAddress('');
    setSpecialInstructions('');
    
    // Simulate real database reaction
    setDonationSuccess(true);
    // Find the newly added item to show on Success screen (it is the newest item)
    setTimeout(() => {
      setDonationSuccess(true);
    }, 100);
  };

  const handleSafetySubmit = () => {
    if (!selectedDonationForSafety) return;
    if (Object.values(safetyChecklist).some(v => !v)) {
      alert('All food safety parameters must be verified and approved.');
      return;
    }

    // Accept donation
    onAcceptDonation(selectedDonationForSafety.id, currentUser.orgName);
    setSelectedDonationForSafety(null);
    setSafetyChecklist({
      freshFood: false,
      properPackaging: false,
      safeTemperature: false,
      cleanContainers: false,
      withinExpiry: false
    });
  };

  const handleVolunteerAssignSubmit = () => {
    if (!selectedDonationForVolunteer || !selectedVolunteerId) return;
    onAssignVolunteer(selectedDonationForVolunteer.id, selectedVolunteerId);
    setSelectedDonationForVolunteer(null);
    setSelectedVolunteerId('');
  };

  const handleBroadcastAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!announcementText) return;
    onAddAnnouncement(announcementText);
    setAnnouncementText('');
    alert('Announcement broadcasted successfully to all devices!');
  };

  const handleApprovePartnerAction = (name: string) => {
    onApprovePartner(name);
    setPendingApprovals(pendingApprovals.filter(p => p.name !== name));
  };

  // Environment metrics calculations
  const myDonations = donations.filter(d => d.restaurantName === currentUser.orgName);
  const totalMealsDonated = myDonations.reduce((sum, d) => sum + (d.status === 'delivered' ? d.estMealsServed : 0), 0);
  const activeDonationsCount = donations.filter(d => d.status !== 'delivered' && d.status !== 'cancelled').length;

  return (
    <div className="flex h-screen bg-gray-50 text-gray-800 font-sans" id="web-layout-root">
      
      {/* SIDEBAR NAVIGATION */}
      <aside className="w-68 bg-gradient-to-b from-green-900 to-green-950 text-white flex flex-col justify-between border-r border-green-800" id="web-sidebar">
        <div>
          {/* Logo Brand */}
          <div className="p-6 border-b border-green-800/60 flex items-center gap-3">
            <img
              src={foodCareLogo}
              alt="Akshaya Patra Logo"
              className="h-25 w-25 object-contain bg-white p-2 rounded-2xl shadow-md"
              referrerPolicy="no-referrer"
            />
            <div>
              <h1 className="text-[29px] font-black tracking-tight text-white leading-none font-['Georgia']">Akshaya Patra</h1>
              <span className="text-xxs text-green-300 font-bold tracking-wider uppercase">Portal Console</span>
            </div>
          </div>

          {/* User Org Card */}
          <div className="mx-4 my-4 p-3 bg-green-800/40 rounded-2xl border border-green-700/40 flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-orange-500 text-white font-black text-center text-xs h-9 w-9 flex items-center justify-center">
              {currentUser.orgName.charAt(0)}
            </div>
            <div className="min-w-0">
              <h3 className="text-xs font-bold text-white truncate">{currentUser.orgName}</h3>
              <span className="text-xxs text-orange-400 capitalize font-semibold flex items-center gap-1">
                🏆 {currentUser.role} Account
              </span>
            </div>
          </div>

          {/* NAV TABS */}
          <nav className="px-3 space-y-1">
            {currentUser.role === 'donor' && (
              <>
                <button
                  onClick={() => { setActiveTab('dashboard'); setDonationSuccess(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition ${
                    activeTab === 'dashboard' ? 'bg-green-700 text-white shadow-md' : 'text-green-100 hover:bg-green-800/50'
                  }`}
                >
                  <LayoutDashboard className="h-4.5 w-4.5" /> Dashboard
                </button>
                <button
                  onClick={() => { setActiveTab('donate'); setDonationSuccess(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition ${
                    activeTab === 'donate' ? 'bg-green-700 text-white shadow-md' : 'text-green-100 hover:bg-green-800/50'
                  }`}
                >
                  <PlusCircle className="h-4.5 w-4.5" /> Donate Food
                </button>
                <button
                  onClick={() => { setActiveTab('history'); setDonationSuccess(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition ${
                    activeTab === 'history' ? 'bg-green-700 text-white shadow-md' : 'text-green-100 hover:bg-green-800/50'
                  }`}
                >
                  <History className="h-4.5 w-4.5" /> Donation History
                </button>
                <button
                  onClick={() => { setActiveTab('analytics'); setDonationSuccess(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition ${
                    activeTab === 'analytics' ? 'bg-green-700 text-white shadow-md' : 'text-green-100 hover:bg-green-800/50'
                  }`}
                >
                  <BarChart3 className="h-4.5 w-4.5" /> Analytics Dashboard
                </button>
                <button
                  onClick={() => { setActiveTab('rewards'); setDonationSuccess(false); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition ${
                    activeTab === 'rewards' ? 'bg-green-700 text-white shadow-md' : 'text-green-100 hover:bg-green-800/50'
                  }`}
                >
                  <Award className="h-4.5 w-4.5" /> Rewards & Impact
                </button>
              </>
            )}

            {currentUser.role === 'ngo' && (
              <>
                <button
                  onClick={() => { setActiveTab('dashboard'); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition ${
                    activeTab === 'dashboard' ? 'bg-green-700 text-white shadow-md' : 'text-green-100 hover:bg-green-800/50'
                  }`}
                >
                  <LayoutDashboard className="h-4.5 w-4.5" /> Nearby Donations
                </button>
                <button
                  onClick={() => { setActiveTab('volunteers'); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition ${
                    activeTab === 'volunteers' ? 'bg-green-700 text-white shadow-md' : 'text-green-100 hover:bg-green-800/50'
                  }`}
                >
                  <UserCheck className="h-4.5 w-4.5" /> Volunteer Management
                </button>
                <button
                  onClick={() => { setActiveTab('history'); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition ${
                    activeTab === 'history' ? 'bg-green-700 text-white shadow-md' : 'text-green-100 hover:bg-green-800/50'
                  }`}
                >
                  <History className="h-4.5 w-4.5" /> NGO History
                </button>
                <button
                  onClick={() => { setActiveTab('rewards'); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition ${
                    activeTab === 'rewards' ? 'bg-green-700 text-white shadow-md' : 'text-green-100 hover:bg-green-800/50'
                  }`}
                >
                  <TrendingUp className="h-4.5 w-4.5" /> Impact Dashboard
                </button>
              </>
            )}

            {currentUser.role === 'admin' && (
              <>
                <button
                  onClick={() => { setActiveTab('dashboard'); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition ${
                    activeTab === 'dashboard' ? 'bg-green-700 text-white shadow-md' : 'text-green-100 hover:bg-green-800/50'
                  }`}
                >
                  <LayoutDashboard className="h-4.5 w-4.5" /> Admin Console
                </button>
                <button
                  onClick={() => { setActiveTab('approvals'); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition ${
                    activeTab === 'approvals' ? 'bg-green-700 text-white shadow-md' : 'text-green-100 hover:bg-green-800/50'
                  }`}
                >
                  <CheckCircle2 className="h-4.5 w-4.5" /> Pending Approvals
                </button>
                <button
                  onClick={() => { setActiveTab('history'); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition ${
                    activeTab === 'history' ? 'bg-green-700 text-white shadow-md' : 'text-green-100 hover:bg-green-800/50'
                  }`}
                >
                  <History className="h-4.5 w-4.5" /> Monitor Donations
                </button>
                <button
                  onClick={() => { setActiveTab('announcements'); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition ${
                    activeTab === 'announcements' ? 'bg-green-700 text-white shadow-md' : 'text-green-100 hover:bg-green-800/50'
                  }`}
                >
                  <Send className="h-4.5 w-4.5" /> Broadcast Announcements
                </button>
              </>
            )}

            <button
              onClick={() => { setActiveTab('settings'); setDonationSuccess(false); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold transition ${
                activeTab === 'settings' ? 'bg-green-700 text-white shadow-md' : 'text-green-100 hover:bg-green-800/50'
              }`}
            >
              <Settings className="h-4.5 w-4.5" /> Settings
            </button>
          </nav>
        </div>

        {/* LOGOUT */}
        <div className="p-4 border-t border-green-800/60">
          <div className="mb-3 text-xxs text-green-300 flex items-center gap-1">
            <User className="h-3.5 w-3.5 text-orange-400" /> Logged in: {currentUser.name}
          </div>
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 bg-green-850 hover:bg-orange-600 text-white font-bold py-2.5 px-4 rounded-xl text-xs transition border border-green-800/40"
          >
            <LogOut className="h-4 w-4" /> Log Out
          </button>
        </div>
      </aside>

      {/* MAIN VIEW AREA */}
      <main className="flex-1 overflow-y-auto flex flex-col" id="web-main-body">
        
        {/* TOP BAR / DESKTOP HEADER */}
        <header className="bg-white border-b border-gray-150 py-4 px-8 flex justify-between items-center shadow-xxs">
          <div>
            <h2 className="text-xl font-bold text-gray-800 tracking-tight capitalize">
              {activeTab === 'dashboard' ? `${currentUser.role} Dashboard` : activeTab.replace('_', ' ')}
            </h2>
            <p className="text-xxs text-gray-500">
              Welcome back, <span className="font-semibold">{currentUser.name}</span>. Managing <span className="text-green-700 font-bold">{currentUser.orgName}</span>.
            </p>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden lg:flex flex-col text-right">
              <span className="text-xxs text-gray-400 font-bold uppercase">Shared Firebase State</span>
              <span className="text-xs text-green-700 font-bold flex items-center gap-1 justify-end">
                <span className="h-2 w-2 rounded-full bg-green-500 animate-ping"></span> Synchronized Live
              </span>
            </div>
          </div>
        </header>

        {/* CONTAINER VIEW FOR EACH TAB */}
        <div className="p-8 max-w-7xl mx-auto w-full flex-1">
          
          {/* ========================================================
              RESTAURANT PORTAL (donor)
             ======================================================== */}

          {currentUser.role === 'donor' && activeTab === 'dashboard' && (
            <div className="space-y-6" id="donor-dashboard-tab">
              {/* Stat Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                <div className="bg-white p-5 rounded-2xl border border-gray-150 shadow-sm flex items-center justify-between">
                  <div>
                    <p className="text-xxs font-bold text-gray-400 uppercase tracking-wider">Today's Active Listings</p>
                    <h3 className="text-2xl font-black text-gray-900 mt-1">
                      {donations.filter(d => d.restaurantName === currentUser.orgName && d.status !== 'delivered' && d.status !== 'cancelled').length}
                    </h3>
                    <p className="text-xxs text-green-700 font-semibold mt-1">Waiting NGO dispatch</p>
                  </div>
                  <div className="p-3.5 bg-green-50 text-green-700 rounded-2xl">
                    <Clock className="h-6 w-6" />
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-gray-150 shadow-sm flex items-center justify-between">
                  <div>
                    <p className="text-xxs font-bold text-gray-400 uppercase tracking-wider">Total Meals Saved</p>
                    <h3 className="text-2xl font-black text-gray-900 mt-1">{totalMealsDonated || 512} Meals</h3>
                    <p className="text-xxs text-orange-600 font-semibold mt-1">All-time contribution</p>
                  </div>
                  <div className="p-3.5 bg-orange-50 text-orange-600 rounded-2xl">
                    <Award className="h-6 w-6" />
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-gray-150 shadow-sm flex items-center justify-between">
                  <div>
                    <p className="text-xxs font-bold text-gray-400 uppercase tracking-wider">Carbon Footprint Saved</p>
                    <h3 className="text-2xl font-black text-gray-900 mt-1">{(totalMealsDonated ? totalMealsDonated * 0.45 : 230).toFixed(1)} kg</h3>
                    <p className="text-xxs text-green-700 font-semibold mt-1 flex items-center gap-1">
                      <Leaf className="h-3 w-3 text-green-600" /> CO₂ Avoided
                    </p>
                  </div>
                  <div className="p-3.5 bg-green-50 text-green-700 rounded-2xl">
                    <Leaf className="h-6 w-6" />
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-gray-150 shadow-sm flex items-center justify-between">
                  <div>
                    <p className="text-xxs font-bold text-gray-400 uppercase tracking-wider">Water Footprint Retained</p>
                    <h3 className="text-2xl font-black text-gray-900 mt-1">{totalMealsDonated ? totalMealsDonated * 65 : 15400} L</h3>
                    <p className="text-xxs text-blue-600 font-semibold mt-1">Resource saved</p>
                  </div>
                  <div className="p-3.5 bg-blue-50 text-blue-600 rounded-2xl">
                    <Droplet className="h-6 w-6" />
                  </div>
                </div>
              </div>

              {/* Grid content */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Active Donations Detail List */}
                <div className="lg:col-span-2 space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-extrabold text-sm text-gray-800 uppercase tracking-wider">Your Active Food Donations</h3>
                    <button onClick={() => setActiveTab('donate')} className="text-xxs font-bold text-green-700 hover:underline flex items-center gap-1">
                      + Create New Listing
                    </button>
                  </div>

                  {donations.filter(d => d.restaurantName === currentUser.orgName && d.status !== 'delivered' && d.status !== 'cancelled').length === 0 ? (
                    <div className="bg-white rounded-2xl border border-gray-150 p-8 text-center text-gray-400">
                      <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm font-semibold">No active food listings currently.</p>
                      <p className="text-xs">Any food you listing will appear here in real time.</p>
                      <button onClick={() => setActiveTab('donate')} className="mt-4 bg-green-700 text-white font-bold py-2 px-4 rounded-xl text-xs hover:bg-green-800">
                        Donate Now
                      </button>
                    </div>
                  ) : (
                    donations.filter(d => d.restaurantName === currentUser.orgName && d.status !== 'delivered' && d.status !== 'cancelled').map(donation => (
                      <div key={donation.id} className="bg-white rounded-2xl border border-gray-150 p-5 shadow-xs flex flex-col md:flex-row gap-5 hover:border-green-200 transition">
                        <div className="flex-1 space-y-3">
                          <div className="flex items-center justify-between">
                            <span className={`text-xxs font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                              donation.vegNonVeg === 'Veg' ? 'bg-green-100 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'
                            }`}>
                              🟢 {donation.vegNonVeg} • {donation.category}
                            </span>
                            <span className="text-xxs font-black bg-orange-500 text-white px-2 py-0.5 rounded-full uppercase tracking-wider">
                              Status: {donation.status.replace('_', ' ')}
                            </span>
                          </div>

                          <div>
                            <h4 className="font-extrabold text-gray-900 text-base">{donation.foodName}</h4>
                            <p className="text-xs text-gray-500 flex items-center gap-1 mt-0.5">
                              <MapPin className="h-3.5 w-3.5 text-gray-400" /> {donation.location}
                            </p>
                          </div>

                          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-xxs bg-gray-50 p-3 rounded-xl">
                            <div>
                              <span className="text-gray-400 block font-medium">Quantity</span>
                              <span className="font-bold text-gray-800">{donation.quantity}</span>
                            </div>
                            <div>
                              <span className="text-gray-400 block font-medium">Expiry</span>
                              <span className="font-bold text-rose-600">{donation.expiryTime}</span>
                            </div>
                            <div>
                              <span className="text-gray-400 block font-medium">Recipient NGO</span>
                              <span className="font-bold text-green-800 truncate block">{donation.ngoName || 'Matching...'}</span>
                            </div>
                          </div>

                          {donation.volunteerName && (
                            <div className="bg-green-50 text-green-800 text-xxs p-2.5 rounded-xl border border-green-100 flex items-center justify-between">
                              <div>
                                <span className="font-bold">Volunteer:</span> {donation.volunteerName} ({donation.volunteerPhone})
                              </div>
                              <div className="font-semibold text-orange-600">
                                On the way 🚚
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Embed Smart AI engine calculations for this card */}
                        <div className="w-full md:w-72 bg-gray-50/50 p-4 rounded-xl border border-gray-100">
                          <AIRecommendations donation={donation} showTitle={false} />
                        </div>
                      </div>
                    ))
                  )}
                </div>

                {/* Sidebar widgets for AI insights and local leader board */}
                <div className="space-y-6">
                  {/* Local AI trends forecasting block */}
                  <AIPredictiveTrends />

                  {/* Rewards tier and local leaderboard */}
                  <div className="bg-white rounded-2xl border border-gray-150 p-5 shadow-sm">
                    <h3 className="font-extrabold text-sm text-gray-800 uppercase tracking-wider mb-4">🏆 Top Donor Leaderboard</h3>
                    <div className="space-y-3">
                      {leaderboard.map((item, idx) => (
                        <div key={idx} className={`p-2.5 rounded-xl flex items-center justify-between ${
                          item.restaurantName === currentUser.orgName ? 'bg-orange-50 border border-orange-200' : 'bg-gray-50'
                        }`}>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-gray-400 w-4">#{idx + 1}</span>
                            <div className="min-w-0">
                              <span className="text-xs font-bold block truncate text-gray-800">{item.restaurantName}</span>
                              <span className="text-xxs font-semibold text-gray-400 block">{item.badge}</span>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="text-xs font-black text-gray-900 block">{item.mealsDonated}</span>
                            <span className="text-xxs text-gray-400 font-medium">Meals</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* DONATE FOOD FORM TAB */}
          {currentUser.role === 'donor' && activeTab === 'donate' && (
            <div className="max-w-3xl mx-auto" id="donor-donate-tab">
              {donationSuccess ? (
                <div className="bg-white border border-gray-150 p-8 rounded-3xl text-center shadow-lg space-y-6" id="donation-success-panel">
                  <div className="inline-flex p-4 bg-green-50 text-green-700 rounded-full">
                    <CheckCircle2 className="h-16 w-16 animate-bounce" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-black text-green-800">Donation Listed Successfully!</h2>
                    <p className="text-xs text-gray-500 mt-1 max-w-sm mx-auto">
                      Thank you! Your donation has been instantly added to the shared Firebase database. Matching nearby NGOs in real time.
                    </p>
                  </div>

                  <div className="bg-gradient-to-br from-green-50 to-orange-50 border border-green-100 rounded-2xl p-5 text-left space-y-3">
                    <div className="flex items-center gap-2 text-green-800 font-bold text-xs border-b border-green-100 pb-2">
                      <Sparkles className="h-4.5 w-4.5" /> Predictive AI Audit Report
                    </div>
                    <div className="grid grid-cols-2 gap-3 text-xxs">
                      <div>
                        <span className="text-gray-400 block">Carbon Offset Saved</span>
                        <span className="font-bold text-gray-800">~22.5 kg CO₂</span>
                      </div>
                      <div>
                        <span className="text-gray-400 block">Estimated Hungry Fed</span>
                        <span className="font-bold text-gray-800">~50 meals served</span>
                      </div>
                      <div>
                        <span className="text-gray-400 block">Donation Priority Score</span>
                        <span className="font-bold text-orange-600 bg-orange-50 px-1 py-0.5 rounded">9.2 / 10.0</span>
                      </div>
                      <div>
                        <span className="text-gray-400 block">Suggested Dispatch Partner</span>
                        <span className="font-bold text-green-700">Helping Hands Foundation (1.8 km)</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3 justify-center">
                    <button
                      onClick={() => {
                        setDonationSuccess(false);
                        setActiveTab('dashboard');
                      }}
                      className="bg-green-700 hover:bg-green-800 text-white font-bold py-3 px-6 rounded-xl text-xs shadow-md transition"
                    >
                      Go to Dashboard
                    </button>
                    <button
                      onClick={() => setDonationSuccess(false)}
                      className="bg-white border border-gray-200 text-gray-700 font-semibold py-3 px-6 rounded-xl text-xs hover:bg-gray-50 transition"
                    >
                      Donate Again
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleDonateSubmit} className="bg-white border border-gray-150 rounded-2xl p-6 shadow-sm space-y-6">
                  <div className="border-b border-gray-100 pb-4">
                    <h3 className="text-lg font-black text-gray-800">List Surplus Food Donation</h3>
                    <p className="text-xxs text-gray-500 mt-1">
                      Our system uses real-time AI to calculate priority scores, match nearby shelters, and dispatch verification riders.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">Food Name <span className="text-rose-500">*</span></label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Mixed Veg Curry and Roti"
                        value={foodName}
                        onChange={(e) => setFoodName(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">Food Category</label>
                      <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-xs bg-white"
                      >
                        <option>Main Course</option>
                        <option>Bakery Items</option>
                        <option>Sweets & Desserts</option>
                        <option>Groceries & Raw Veggies</option>
                        <option>Packaged Food</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">Veg / Non-Veg Option</label>
                      <div className="flex gap-4">
                        <label className="flex items-center gap-2 text-xs font-semibold text-gray-700 cursor-pointer">
                          <input
                            type="radio"
                            name="vegNonVeg"
                            checked={vegNonVeg === 'Veg'}
                            onChange={() => setVegNonVeg('Veg')}
                            className="text-green-700 focus:ring-green-600"
                          />
                          🟢 Veg
                        </label>
                        <label className="flex items-center gap-2 text-xs font-semibold text-gray-700 cursor-pointer">
                          <input
                            type="radio"
                            name="vegNonVeg"
                            checked={vegNonVeg === 'Non-Veg'}
                            onChange={() => setVegNonVeg('Non-Veg')}
                            className="text-green-700 focus:ring-green-600"
                          />
                          🔴 Non-Veg
                        </label>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">Quantity <span className="text-rose-500">*</span></label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. 50 Meals, 15 kg"
                        value={quantity}
                        onChange={(e) => setQuantity(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">Preparation Time</label>
                      <input
                        type="text"
                        placeholder="e.g. 12:30 PM"
                        value={prepTime}
                        onChange={(e) => setPrepTime(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">Expiry Time <span className="text-rose-500">*</span></label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. 5:00 PM (or in 4 hours)"
                        value={expiryTime}
                        onChange={(e) => setExpiryTime(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-xs"
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-xs font-semibold text-gray-700 mb-1">Pickup Address <span className="text-rose-500">*</span></label>
                      <input
                        type="text"
                        required
                        placeholder="Full restaurant floor or street address"
                        value={pickupAddress}
                        onChange={(e) => setPickupAddress(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">Geographical City Sector</label>
                      <input
                        type="text"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-xs bg-gray-50 cursor-not-allowed"
                        disabled
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">Food Condition</label>
                      <input
                        type="text"
                        placeholder="e.g. Hot and fresh, stored in warming trays"
                        value={condition}
                        onChange={(e) => setCondition(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-xs"
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-xs font-semibold text-gray-700 mb-1">Upload Food Image (Simulated URL)</label>
                      <input
                        type="text"
                        placeholder="Auto generated or placeholder layout URL"
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-xs bg-gray-50"
                        value="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400"
                        disabled
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-xs font-semibold text-gray-700 mb-1">Special Instructions & Packaging details</label>
                      <textarea
                        rows={3}
                        placeholder="e.g. Bring own storage containers, ask for manager Ramesh on duty."
                        value={specialInstructions}
                        onChange={(e) => setSpecialInstructions(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-xs"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-green-700 hover:bg-green-800 text-white font-bold py-3.5 px-6 rounded-xl text-xs shadow-md transition transform hover:-translate-y-0.5"
                  >
                    Submit Donation Listing to Firebase State
                  </button>
                </form>
              )}
            </div>
          )}

          {/* DONATION HISTORY LIST / SEARCH TAB */}
          {activeTab === 'history' && (
            <div className="bg-white rounded-2xl border border-gray-150 p-6 shadow-sm space-y-4" id="donor-history-tab">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-gray-100 pb-4">
                <div>
                  <h3 className="text-base font-extrabold text-gray-800">Donations Audit Log</h3>
                  <p className="text-xxs text-gray-500">View and audit all food safety, NGO recipients, and delivery logs.</p>
                </div>

                <div className="flex flex-wrap gap-2">
                  <button 
                    onClick={() => setFilterStatus('all')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                      filterStatus === 'all' ? 'bg-green-700 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-600'
                    }`}
                  >
                    All Logs
                  </button>
                  <button 
                    onClick={() => setFilterStatus('pending')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                      filterStatus === 'pending' ? 'bg-green-700 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-600'
                    }`}
                  >
                    Pending Match
                  </button>
                  <button 
                    onClick={() => setFilterStatus('assigned')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                      filterStatus === 'assigned' ? 'bg-green-700 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-600'
                    }`}
                  >
                    In Progress
                  </button>
                  <button 
                    onClick={() => setFilterStatus('delivered')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                      filterStatus === 'delivered' ? 'bg-green-700 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-600'
                    }`}
                  >
                    Completed Deliveries
                  </button>
                </div>
              </div>

              {/* Table section */}
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-gray-150 text-xxs font-extrabold text-gray-400 uppercase tracking-wider bg-gray-50">
                      <th className="py-3 px-4">Food Description</th>
                      <th className="py-3 px-4">Listed By</th>
                      <th className="py-3 px-4">Qty / Prep</th>
                      <th className="py-3 px-4">Expiry Limit</th>
                      <th className="py-3 px-4">NGO Recipient</th>
                      <th className="py-3 px-4">Rider / Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 text-xs">
                    {donations
                      .filter(d => currentUser.role === 'admin' || d.restaurantName === currentUser.orgName || d.ngoName === currentUser.orgName)
                      .filter(d => filterStatus === 'all' || d.status === filterStatus)
                      .map(donation => (
                        <tr key={donation.id} className="hover:bg-gray-50/50">
                          <td className="py-4 px-4 font-bold text-gray-900">
                            <div>{donation.foodName}</div>
                            <span className="text-xxs font-medium text-gray-400">{donation.category}</span>
                          </td>
                          <td className="py-4 px-4 text-gray-600 font-semibold">{donation.restaurantName}</td>
                          <td className="py-4 px-4">
                            <span className="font-bold block text-gray-800">{donation.quantity}</span>
                            <span className="text-xxs text-gray-400">{donation.prepTime}</span>
                          </td>
                          <td className="py-4 px-4 font-bold text-rose-600">{donation.expiryTime}</td>
                          <td className="py-4 px-4 text-green-800 font-semibold">{donation.ngoName || 'Matching nearby...'}</td>
                          <td className="py-4 px-4">
                            <div className="flex items-center gap-2">
                              <span className={`px-2.5 py-1 rounded-full text-xxs font-bold uppercase tracking-wider ${
                                donation.status === 'delivered' ? 'bg-green-100 text-green-700' :
                                donation.status === 'cancelled' ? 'bg-red-100 text-red-700' :
                                donation.status === 'pending' ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'
                              }`}>
                                {donation.status.replace('_', ' ')}
                              </span>
                            </div>
                            <span className="text-xxs text-gray-400 block mt-1">{donation.volunteerName || 'Rider unassigned'}</span>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ANALYTICS CHARTS TAB */}
          {currentUser.role === 'donor' && activeTab === 'analytics' && (
            <div className="space-y-6" id="donor-analytics-tab">
              {/* Stats highlights */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-5 rounded-2xl border border-gray-150 shadow-sm text-center">
                  <span className="text-xxs font-bold text-gray-400 uppercase tracking-widest block mb-1">CO₂ Emissions Diverted</span>
                  <h3 className="text-3xl font-black text-green-700">230.4 kg</h3>
                  <p className="text-xxs text-gray-500 mt-1 max-w-xs mx-auto">Equivalent to planting 11 newly matured urban teak trees.</p>
                </div>
                <div className="bg-white p-5 rounded-2xl border border-gray-150 shadow-sm text-center">
                  <span className="text-xxs font-bold text-gray-400 uppercase tracking-widest block mb-1">Water Footprint Retained</span>
                  <h3 className="text-3xl font-black text-blue-600">34,000 L</h3>
                  <p className="text-xxs text-gray-500 mt-1 max-w-xs mx-auto">Equivalent to domestic drinking water supply for 85 days.</p>
                </div>
                <div className="bg-white p-5 rounded-2xl border border-gray-150 shadow-sm text-center">
                  <span className="text-xxs font-bold text-gray-400 uppercase tracking-widest block mb-1">Donation Efficiency Rate</span>
                  <h3 className="text-3xl font-black text-orange-600">98.2%</h3>
                  <p className="text-xxs text-gray-500 mt-1 max-w-xs mx-auto">Percentage of listings verified, claimed, and consumed successfully.</p>
                </div>
              </div>

              {/* Simulated Charts layout */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* SVG Bar Chart representing daily listings */}
                <div className="bg-white p-6 rounded-2xl border border-gray-150 shadow-sm">
                  <h4 className="font-extrabold text-sm text-gray-800 uppercase mb-6 tracking-wide">Daily Meals Saved (This Week)</h4>
                  
                  <div className="flex items-end justify-between h-48 pt-4 px-2">
                    {[
                      { day: 'Mon', count: 420 },
                      { day: 'Tue', count: 550 },
                      { day: 'Wed', count: 490 },
                      { day: 'Thu', count: 680 },
                      { day: 'Fri', count: 820 },
                      { day: 'Sat', count: 1100 },
                      { day: 'Sun', count: 950 }
                    ].map((d, idx) => (
                      <div key={idx} className="flex flex-col items-center gap-2 flex-1 group">
                        <span className="text-xxs font-extrabold text-gray-500 opacity-0 group-hover:opacity-100 transition">{d.count}</span>
                        <div 
                          className="w-8 bg-green-700 hover:bg-orange-500 rounded-t-lg transition-all duration-300" 
                          style={{ height: `${(d.count / 1100) * 120}px` }}
                        ></div>
                        <span className="text-xxs font-bold text-gray-400">{d.day}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* SVG Line Chart showing carbon reduction progress */}
                <div className="bg-white p-6 rounded-2xl border border-gray-150 shadow-sm">
                  <h4 className="font-extrabold text-sm text-gray-800 uppercase mb-6 tracking-wide">Monthly Carbon (CO₂) Mitigated</h4>
                  
                  <div className="flex items-end justify-between h-48 pt-4 px-2 border-l border-b border-gray-100 relative">
                    {/* Simulated lines using overlay indicators */}
                    <div className="absolute inset-0 flex flex-col justify-between py-2 text-xxs text-gray-300 font-mono">
                      <span>1500kg</span>
                      <span>1000kg</span>
                      <span>500kg</span>
                      <span>0kg</span>
                    </div>

                    {[
                      { month: 'Jan', co2: 690 },
                      { month: 'Feb', co2: 810 },
                      { month: 'Mar', co2: 1100 },
                      { month: 'Apr', co2: 1250 },
                      { month: 'May', co2: 1410 },
                      { month: 'Jun', co2: 1540 }
                    ].map((d, idx) => (
                      <div key={idx} className="flex flex-col items-center gap-2 flex-1 relative z-10">
                        <span className="text-xxs font-bold text-green-700">{d.co2}kg</span>
                        <div 
                          className="w-3 bg-gradient-to-t from-green-800 to-green-600 rounded-t-full" 
                          style={{ height: `${(d.co2 / 1600) * 110}px` }}
                        ></div>
                        <span className="text-xxs font-extrabold text-gray-400">{d.month}</span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* REWARDS & CERTIFICATES TAB */}
          {activeTab === 'rewards' && (
            <div className="space-y-6" id="donor-rewards-tab">
              <div className="bg-gradient-to-r from-orange-500 to-amber-500 rounded-3xl p-8 text-white flex flex-col lg:flex-row justify-between items-center gap-6 shadow-md">
                <div className="space-y-3 text-center lg:text-left">
                  <span className="bg-white/20 text-white text-xxs font-black px-3 py-1 rounded-full uppercase tracking-wider">ABC Restaurant Partner Badge</span>
                  <h2 className="text-3xl font-black">🌟 Platinum Donor Status Unlocked!</h2>
                  <p className="text-xs text-orange-50 max-w-md">
                    Incredible! By contributing surplus food feeding over 500+ individuals, you have attained the highest platform tier.
                  </p>
                </div>

                <div className="flex gap-4">
                  <div className="bg-white/10 p-4 rounded-2xl border border-white/20 text-center">
                    <span className="text-xxs text-orange-100 block">Total Badges</span>
                    <span className="text-2xl font-black">12 Earned</span>
                  </div>
                  <div className="bg-white/10 p-4 rounded-2xl border border-white/20 text-center">
                    <span className="text-xxs text-orange-100 block">National Rank</span>
                    <span className="text-2xl font-black">#14 Local</span>
                  </div>
                </div>
              </div>

              {/* Certificates grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-2xl border border-gray-150 shadow-sm flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="p-3 bg-green-50 text-green-700 rounded-2xl inline-flex">
                      <FileSpreadsheet className="h-6 w-6" />
                    </div>
                    <h3 className="font-extrabold text-base text-gray-900">Certificate of Environmental Stewardship</h3>
                    <p className="text-xs text-gray-500">
                      Generated dynamically referencing your carbon emissions saved (230.4 kg) and water footprint savings (34,000L).
                    </p>
                  </div>
                  <button 
                    onClick={() => alert('Certificate downloaded to Downloads/ABC-Stewardship-July-2026.pdf (Simulated)')}
                    className="mt-6 w-full bg-green-700 hover:bg-green-800 text-white font-bold py-2.5 px-4 rounded-xl text-xs shadow-xs"
                  >
                    Download Certificate (PDF)
                  </button>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-gray-150 shadow-sm flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="p-3 bg-orange-50 text-orange-600 rounded-2xl inline-flex">
                      <FileText className="h-6 w-6" />
                    </div>
                    <h3 className="font-extrabold text-base text-gray-900">Tax Deductibility (Form 80G) Summary</h3>
                    <p className="text-xs text-gray-500">
                      Annual certified statement of commercial retail value of food materials contributed to Helping Hands Foundation shelter.
                    </p>
                  </div>
                  <button 
                    onClick={() => alert('Tax statement downloaded to Downloads/ABC-Tax-Summary-Form80G.xlsx (Simulated)')}
                    className="mt-6 w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-2.5 px-4 rounded-xl text-xs shadow-xs"
                  >
                    Export 80G Tax Summary (Excel)
                  </button>
                </div>
              </div>
            </div>
          )}


          {/* ========================================================
              NGO PORTAL (ngo)
             ======================================================== */}

          {currentUser.role === 'ngo' && activeTab === 'dashboard' && (
            <div className="space-y-6" id="ngo-dashboard-tab">
              {/* Stat panel */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                <div className="bg-white p-5 rounded-2xl border border-gray-150 shadow-sm">
                  <span className="text-xxs text-gray-400 font-bold uppercase tracking-wider block">Surplus Nearby Food Available</span>
                  <h3 className="text-2xl font-black text-gray-950 mt-1">
                    {donations.filter(d => d.status === 'pending').length} Active Listings
                  </h3>
                  <p className="text-xxs text-orange-600 font-semibold mt-1">Within 5 km range of {currentUser.orgName}</p>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-gray-150 shadow-sm">
                  <span className="text-xxs text-gray-400 font-bold uppercase tracking-wider block">Accepted Claims In Progress</span>
                  <h3 className="text-2xl font-black text-gray-950 mt-1">
                    {donations.filter(d => d.ngoName === currentUser.orgName && d.status !== 'delivered' && d.status !== 'cancelled').length} Shipments
                  </h3>
                  <p className="text-xxs text-green-700 font-semibold mt-1">Assigned or pending volunteer transport</p>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-gray-150 shadow-sm">
                  <span className="text-xxs text-gray-400 font-bold uppercase tracking-wider block">Total Individuals Nourished</span>
                  <h3 className="text-2xl font-black text-gray-950 mt-1">
                    {donations.filter(d => d.ngoName === currentUser.orgName && d.status === 'delivered').reduce((sum, d) => sum + d.estMealsServed, 0) || 320} Saved Meals
                  </h3>
                  <p className="text-xxs text-blue-600 font-semibold mt-1">Synchronized directly to platform metrics</p>
                </div>
              </div>

              {/* Interactive Nearby list */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                <div className="lg:col-span-2 space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-extrabold text-sm text-gray-800 uppercase tracking-wider">⚠️ Unclaimed Nearby Surplus Listings</h3>
                    <span className="text-xxs font-bold text-gray-400">Sorted by distance & expiry score</span>
                  </div>

                  {donations.filter(d => d.status === 'pending').length === 0 ? (
                    <div className="bg-white rounded-2xl border border-gray-150 p-8 text-center text-gray-400">
                      <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm font-semibold">No unclaimed surplus food in your vicinity right now.</p>
                      <p className="text-xs">We will alert your NGO with push notifications immediately when a donor lists surplus.</p>
                    </div>
                  ) : (
                    donations.filter(d => d.status === 'pending').map(donation => (
                      <div key={donation.id} className="bg-white rounded-2xl border border-gray-150 p-5 shadow-xs hover:border-green-300 transition flex flex-col md:flex-row gap-5">
                        <div className="flex-1 space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="bg-green-100 text-green-700 text-xxs font-bold px-2.5 py-0.5 rounded-full border border-green-200">
                              🟢 {donation.vegNonVeg} • {donation.category}
                            </span>
                            <span className="text-xxs font-black text-orange-600">
                              ⏳ Expires in {donation.expiryTime}
                            </span>
                          </div>

                          <div>
                            <span className="text-xxs text-gray-400 font-bold block">{donation.restaurantName}</span>
                            <h4 className="font-extrabold text-gray-900 text-base">{donation.foodName}</h4>
                            <p className="text-xs text-gray-500 flex items-center gap-1 mt-0.5">
                              <MapPin className="h-3.5 w-3.5 text-gray-400" /> {donation.location} ({donation.distanceKm} km away)
                            </p>
                          </div>

                          <div className="bg-gray-50 p-3 rounded-xl grid grid-cols-3 gap-2 text-xxs">
                            <div>
                              <span className="text-gray-400 block font-medium">Quantity Available</span>
                              <span className="font-bold text-gray-800">{donation.quantity}</span>
                            </div>
                            <div>
                              <span className="text-gray-400 block font-medium">Preparation</span>
                              <span className="font-bold text-gray-800">{donation.prepTime}</span>
                            </div>
                            <div>
                              <span className="text-gray-400 block font-medium">Condition</span>
                              <span className="font-bold text-gray-800">{donation.condition}</span>
                            </div>
                          </div>

                          {donation.specialInstructions && (
                            <p className="text-xxs text-gray-500 italic">
                              <span className="font-semibold text-gray-700">Special Note:</span> {donation.specialInstructions}
                            </p>
                          )}

                          <div className="flex gap-2 pt-2">
                            <button
                              onClick={() => setSelectedDonationForSafety(donation)}
                              className="bg-green-700 hover:bg-green-800 text-white font-bold py-2.5 px-4 rounded-xl text-xs transition"
                            >
                              Accept Food Donation
                            </button>
                            <button 
                              onClick={() => alert(`Simulated Route Map from ${donation.restaurantName} to ${currentUser.orgName}`)}
                              className="bg-white border border-gray-200 text-gray-700 font-bold py-2.5 px-4 rounded-xl text-xs hover:bg-gray-50 transition"
                            >
                              View Pickup Route
                            </button>
                          </div>
                        </div>

                        {/* Embed AI match report directly on NGO dashboard */}
                        <div className="w-full md:w-72 bg-gray-50/50 p-4 rounded-xl border border-gray-100">
                          <AIRecommendations donation={donation} showTitle={true} />
                        </div>
                      </div>
                    ))
                  )}
                </div>

                {/* NGO Right hand panel tracking active shipments */}
                <div className="space-y-6">
                  <div className="bg-white rounded-2xl border border-gray-150 p-5 shadow-sm">
                    <h3 className="font-extrabold text-sm text-gray-800 uppercase tracking-wider mb-4">📍 Track Active Pickups</h3>
                    
                    {donations.filter(d => d.ngoName === currentUser.orgName && d.status !== 'delivered' && d.status !== 'cancelled').length === 0 ? (
                      <p className="text-xs text-gray-400 text-center py-4">No active claimed shipments currently.</p>
                    ) : (
                      <div className="space-y-4">
                        {donations.filter(d => d.ngoName === currentUser.orgName && d.status !== 'delivered' && d.status !== 'cancelled').map(donation => (
                          <div key={donation.id} className="border-b border-gray-100 pb-3 last:border-b-0 space-y-2">
                            <div className="flex justify-between items-start">
                              <span className="text-xs font-bold text-gray-800 block truncate">{donation.foodName}</span>
                              <span className="text-xxs font-black text-blue-700 uppercase bg-blue-50 px-1.5 py-0.5 rounded">
                                {donation.status}
                              </span>
                            </div>

                            <p className="text-xxs text-gray-500">Listed by {donation.restaurantName}</p>

                            {donation.volunteerName ? (
                              <div className="p-2 bg-green-50 text-green-800 text-xxs font-semibold rounded-lg flex justify-between items-center">
                                <span>🚚 {donation.volunteerName} assigned</span>
                                <button 
                                  onClick={() => onUpdateStatus(donation.id, 'delivered')}
                                  className="text-orange-600 hover:underline hover:text-orange-700 text-xxs font-black"
                                >
                                  Complete Delivery
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => setSelectedDonationForVolunteer(donation)}
                                className="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-1.5 px-3 rounded-lg text-xxs transition"
                              >
                                ➕ Dispatch Volunteer Rider
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="bg-gradient-to-br from-green-50 to-orange-50 border border-green-100 rounded-2xl p-5 shadow-xs space-y-2">
                    <h4 className="text-xs font-bold text-gray-800 flex items-center gap-1">
                      🎯 Smart NGO Dispatching Suggestions
                    </h4>
                    <p className="text-xxs text-gray-600 leading-normal">
                      The AI model matches your warehouse location of <span className="font-semibold text-green-800">Helping Hands shelter</span> against the shortest congestion route from XYZ Restaurant, saving 12 minutes in urban transit time.
                    </p>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* VOLUNTEER MANAGEMENT TAB */}
          {currentUser.role === 'ngo' && activeTab === 'volunteers' && (
            <div className="bg-white rounded-2xl border border-gray-150 p-6 shadow-sm space-y-6" id="ngo-volunteers-tab">
              <div className="border-b border-gray-100 pb-4">
                <h3 className="text-base font-extrabold text-gray-800">Rider & Volunteer Dispatch Console</h3>
                <p className="text-xxs text-gray-500 mt-1">
                  Manage active field drivers, track completion counts, ratings, and active statuses.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                {volunteers.map(volunteer => (
                  <div key={volunteer.id} className="p-4 rounded-xl border border-gray-150 bg-gray-50/50 space-y-3">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <div className="h-8 w-8 rounded-full bg-green-700 text-white font-black text-xs flex items-center justify-center">
                          {volunteer.name.charAt(0)}
                        </div>
                        <span className="text-xs font-bold text-gray-800">{volunteer.name}</span>
                      </div>
                      <span className={`h-2.5 w-2.5 rounded-full ${
                        volunteer.status === 'available' ? 'bg-green-500' :
                        volunteer.status === 'busy' ? 'bg-orange-500' : 'bg-gray-300'
                      }`} title={volunteer.status}></span>
                    </div>

                    <div className="text-xxs text-gray-500 space-y-1">
                      <div><span className="font-semibold">Phone:</span> {volunteer.phone}</div>
                      <div><span className="font-semibold">Rating:</span> ⭐ {volunteer.rating.toFixed(2)}</div>
                      <div><span className="font-semibold">Total Completed:</span> {volunteer.completedDeliveries} Trips</div>
                      <div><span className="font-semibold text-green-700">Sector:</span> {volunteer.currentLocation}</div>
                    </div>

                    <div className="pt-2">
                      <span className={`w-full inline-block text-center py-1 rounded text-xxs font-extrabold uppercase tracking-wider ${
                        volunteer.status === 'available' ? 'bg-green-100 text-green-700' :
                        volunteer.status === 'busy' ? 'bg-orange-100 text-orange-700' : 'bg-gray-100 text-gray-400'
                      }`}>
                        {volunteer.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}


          {/* ========================================================
              ADMIN PORTAL (admin)
             ======================================================== */}

          {currentUser.role === 'admin' && activeTab === 'dashboard' && (
            <div className="space-y-6" id="admin-dashboard-tab">
              {/* Stat grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
                <div className="bg-white p-4 rounded-2xl border border-gray-150 text-center">
                  <span className="text-xxs text-gray-400 font-bold uppercase">Restaurants</span>
                  <h3 className="text-xl font-black text-gray-900 mt-1">45 Partners</h3>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-gray-150 text-center">
                  <span className="text-xxs text-gray-400 font-bold uppercase">Verified NGOs</span>
                  <h3 className="text-xl font-black text-gray-900 mt-1">18 Shelters</h3>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-gray-150 text-center">
                  <span className="text-xxs text-gray-400 font-bold uppercase">Riders On Duty</span>
                  <h3 className="text-xl font-black text-gray-900 mt-1">64 Active</h3>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-gray-150 text-center">
                  <span className="text-xxs text-gray-400 font-bold uppercase">Total Donations</span>
                  <h3 className="text-xl font-black text-gray-900 mt-1">480 Logs</h3>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-gray-150 text-center">
                  <span className="text-xxs text-gray-400 font-bold uppercase">Meals Distributed</span>
                  <h3 className="text-xl font-black text-gray-900 mt-1">12,450 Meals</h3>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-gray-150 text-center">
                  <span className="text-xxs text-gray-400 font-bold uppercase">Waste Reduced</span>
                  <h3 className="text-xl font-black text-green-700 mt-1">5,200 kg</h3>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Admin user management list */}
                <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-150 p-6 shadow-sm space-y-4">
                  <h3 className="font-extrabold text-sm text-gray-800 uppercase tracking-wider">🔒 Monitor Active Platform Registrations</h3>
                  
                  <div className="divide-y divide-gray-150 text-xs">
                    {[
                      { name: 'ABC Restaurant', type: 'Donor', email: 'manager@abcrestaurant.com', status: 'Approved' },
                      { name: 'Helping Hands Foundation', type: 'NGO', email: 'director@helpinghands.org', status: 'Approved' },
                      { name: 'Bakers Delight', type: 'Donor', email: 'contact@bakersdelight.com', status: 'Approved' },
                      { name: 'Feeding India NGO', type: 'NGO', email: 'volunteer@feedingindia.org', status: 'Approved' }
                    ].map((user, idx) => (
                      <div key={idx} className="py-3 flex justify-between items-center hover:bg-gray-50">
                        <div>
                          <span className="font-bold text-gray-900">{user.name}</span>
                          <span className="text-xxs block text-gray-400">{user.email}</span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-0.5 rounded text-xxs font-bold uppercase tracking-wider ${
                            user.type === 'Donor' ? 'bg-orange-50 text-orange-700 border border-orange-200' : 'bg-green-50 text-green-700 border border-green-200'
                          }`}>
                            {user.type}
                          </span>
                          <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded text-xxs font-bold uppercase">
                            ✓ {user.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right widgets */}
                <div className="space-y-6">
                  {/* System Audit tool */}
                  <div className="bg-gradient-to-br from-green-950 to-green-900 text-white rounded-2xl p-5 shadow-sm space-y-4 border border-green-700">
                    <div className="flex items-center gap-1.5 border-b border-green-800 pb-2">
                      <ShieldCheck className="h-5 w-5 text-orange-400" />
                      <div>
                        <span className="font-bold text-xs block">Firebase Blueprint Audit</span>
                        <span className="text-xxs text-green-300">Firestore security parameters active</span>
                      </div>
                    </div>
                    <p className="text-xxs text-gray-300 leading-normal">
                      Security policy parameters restrict modification of status variables to verified NGO handlers and admin keys only. Verified compliance logs stored successfully.
                    </p>
                    <button 
                      onClick={() => alert('Security rules validated. Compliance green! All devices synchronized.')}
                      className="w-full bg-green-750 hover:bg-green-800 text-white font-bold py-2 rounded-xl text-xxs transition border border-green-700"
                    >
                      Audit Compliance Parameters
                    </button>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* ADMIN APPROVALS TAB */}
          {currentUser.role === 'admin' && activeTab === 'approvals' && (
            <div className="bg-white rounded-2xl border border-gray-150 p-6 shadow-sm space-y-6" id="admin-approvals-tab">
              <div className="border-b border-gray-100 pb-4">
                <h3 className="text-base font-extrabold text-gray-800">Pending Corporate & Shelter Registrations</h3>
                <p className="text-xxs text-gray-500 mt-1">
                  Manual safety credentials check must be completed prior to allowing donations or claiming.
                </p>
              </div>

              {pendingApprovals.length === 0 ? (
                <div className="text-center py-8 text-gray-400">
                  <CheckCircle2 className="h-10 w-10 mx-auto text-green-600 mb-2" />
                  <p className="text-sm font-semibold">All registrations have been approved and verified.</p>
                </div>
              ) : (
                <div className="divide-y divide-gray-100">
                  {pendingApprovals.map((partner, idx) => (
                    <div key={idx} className="py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                      <div>
                        <span className="text-xxs font-black text-orange-600 block uppercase tracking-wider">{partner.type} Request</span>
                        <h4 className="font-bold text-sm text-gray-900">{partner.name}</h4>
                        <p className="text-xxs text-gray-500">Address: {partner.address} • Applied on: {partner.appliedAt}</p>
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() => handleApprovePartnerAction(partner.name)}
                          className="bg-green-700 hover:bg-green-800 text-white font-bold py-1.5 px-4 rounded-xl text-xs transition"
                        >
                          Approve and Authorize
                        </button>
                        <button
                          onClick={() => {
                            setPendingApprovals(pendingApprovals.filter(p => p.name !== partner.name));
                            alert('Registration request rejected');
                          }}
                          className="bg-red-50 text-red-700 font-bold py-1.5 px-4 rounded-xl text-xs hover:bg-red-100 transition"
                        >
                          Reject
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* SYSTEM ANNOUNCEMENTS BROADCAST TAB */}
          {currentUser.role === 'admin' && activeTab === 'announcements' && (
            <div className="max-w-2xl mx-auto bg-white rounded-2xl border border-gray-150 p-6 shadow-sm space-y-6" id="admin-announcements-tab">
              <div>
                <h3 className="text-base font-extrabold text-gray-800">Platform-Wide Dispatch Broadcast</h3>
                <p className="text-xxs text-gray-500">
                  Send high-priority system notifications instantly to all connected donor hotels, NGO workers, and volunteer mobile apps.
                </p>
              </div>

              <form onSubmit={handleBroadcastAnnouncement} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Announcement Alert Message</label>
                  <textarea
                    rows={4}
                    required
                    placeholder="e.g. System Update: High rainfall warning in Madhapur sector. Volunteers advised to drive cautiously and utilize water-insulated carriers."
                    value={announcementText}
                    onChange={(e) => setAnnouncementText(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-green-600 text-xs"
                  />
                </div>

                <div className="bg-orange-50 border border-orange-100 rounded-xl p-3 text-xxs text-gray-600 leading-normal">
                  ⚠️ <span className="font-semibold text-orange-800">Notification Scope:</span> Clicking the button below utilizes Firebase Cloud Messaging (FCM) to trigger live vibration events and push-banner alerts on all device screens.
                </div>

                <button
                  type="submit"
                  className="w-full bg-green-700 hover:bg-green-800 text-white font-bold py-3 px-6 rounded-xl text-xs shadow-md transition"
                >
                  Broadcast Push Notification Alert
                </button>
              </form>
            </div>
          )}


          {/* ========================================================
              COMMON TABS (Settings / Safety Check)
             ======================================================== */}

          {activeTab === 'settings' && (
            <div className="max-w-xl mx-auto bg-white rounded-2xl border border-gray-150 p-6 shadow-sm space-y-6" id="common-settings-tab">
              <div className="border-b border-gray-100 pb-4">
                <h3 className="text-base font-extrabold text-gray-800">Workspace Configurations</h3>
                <p className="text-xxs text-gray-500">Manage real-time state triggers and system parameters.</p>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-gray-100 text-xs">
                  <div>
                    <span className="font-bold block text-gray-800">Firebase Cloud Persistence</span>
                    <span className="text-xxs text-gray-400">Emulate real-time Firestore synchronization endpoints.</span>
                  </div>
                  <span className="bg-green-100 text-green-700 px-2.5 py-1 rounded text-xxs font-extrabold uppercase">
                    ACTIVE
                  </span>
                </div>

                <div className="flex justify-between items-center py-2 border-b border-gray-100 text-xs">
                  <div>
                    <span className="font-bold block text-gray-800">Auto AI Priority Calculation</span>
                    <span className="text-xxs text-gray-400">Calculate scores based on location, traffic, and decay risk.</span>
                  </div>
                  <span className="bg-green-100 text-green-700 px-2.5 py-1 rounded text-xxs font-extrabold uppercase">
                    ENABLED
                  </span>
                </div>

                <div className="flex justify-between items-center py-2 border-b border-gray-100 text-xs">
                  <div>
                    <span className="font-bold block text-gray-800">Demonstration Pre-fill Mode</span>
                    <span className="text-xxs text-gray-400">Prepopulate mock data lists for interactive pitches.</span>
                  </div>
                  <span className="bg-orange-100 text-orange-700 px-2.5 py-1 rounded text-xxs font-extrabold uppercase">
                    MOCK ACTIVE
                  </span>
                </div>
              </div>

              <div className="bg-orange-50 border border-orange-100 rounded-xl p-3 text-xxs text-gray-600">
                💡 <span className="font-bold text-orange-800">Tip for Presentation:</span> To show synchronized actions, click "Donate Food" on the Restaurant Web view, complete submission, then switch to the NGO Web view or Mobile app to see the unclaimed listing appear instantly.
              </div>
            </div>
          )}

        </div>
      </main>

      {/* ========================================================
          MODALS / WORKFLOW FLOATING MODULES
         ======================================================== */}

      {/* 1. FOOD SAFETY VERIFICATION DIALOG */}
      {selectedDonationForSafety && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full border border-gray-100 shadow-2xl space-y-5 animate-scale-up">
            <div className="text-center">
              <div className="inline-flex p-3 bg-green-50 text-green-700 rounded-full mb-2">
                <ShieldCheck className="h-10 w-10" />
              </div>
              <h3 className="text-lg font-black text-gray-900">Food Safety Verification Audit</h3>
              <p className="text-xxs text-gray-500">Akshaya Patra Safe Handling Protocol standards must be verified before claiming.</p>
            </div>

            <div className="space-y-3.5 bg-gray-50 p-4 rounded-xl">
              <label className="flex items-start gap-2.5 text-xs font-semibold text-gray-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={safetyChecklist.freshFood}
                  onChange={(e) => setSafetyChecklist({ ...safetyChecklist, freshFood: e.target.checked })}
                  className="mt-0.5 text-green-700 focus:ring-green-600"
                />
                <div>
                  <span>Fresh Food Inspection Passed</span>
                  <span className="block text-xxs font-medium text-gray-400">Smell, appearance, and touch are pristine.</span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 text-xs font-semibold text-gray-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={safetyChecklist.properPackaging}
                  onChange={(e) => setSafetyChecklist({ ...safetyChecklist, properPackaging: e.target.checked })}
                  className="mt-0.5 text-green-700 focus:ring-green-600"
                />
                <div>
                  <span>Proper Packaging Standard</span>
                  <span className="block text-xxs font-medium text-gray-400">Insulated warming boxes or sealed containers used.</span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 text-xs font-semibold text-gray-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={safetyChecklist.safeTemperature}
                  onChange={(e) => setSafetyChecklist({ ...safetyChecklist, safeTemperature: e.target.checked })}
                  className="mt-0.5 text-green-700 focus:ring-green-600"
                />
                <div>
                  <span>Safe Storing Temperature</span>
                  <span className="block text-xxs font-medium text-gray-400">Maintained above 60°C or below 4°C prior to pickup.</span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 text-xs font-semibold text-gray-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={safetyChecklist.cleanContainers}
                  onChange={(e) => setSafetyChecklist({ ...safetyChecklist, cleanContainers: e.target.checked })}
                  className="mt-0.5 text-green-700 focus:ring-green-600"
                />
                <div>
                  <span>Sanitized Containers</span>
                  <span className="block text-xxs font-medium text-gray-400">Vessels sanitized under state health guidelines.</span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 text-xs font-semibold text-gray-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={safetyChecklist.withinExpiry}
                  onChange={(e) => setSafetyChecklist({ ...safetyChecklist, withinExpiry: e.target.checked })}
                  className="mt-0.5 text-green-700 focus:ring-green-600"
                />
                <div>
                  <span>Strictly Within Expiry Time</span>
                  <span className="block text-xxs font-medium text-gray-400">Consumption window has at least 2 hours remaining.</span>
                </div>
              </label>
            </div>

            <div className="flex gap-2">
              <button
                onClick={handleSafetySubmit}
                className="flex-1 bg-green-700 hover:bg-green-800 text-white font-bold py-2.5 rounded-xl text-xs"
              >
                Approve and Continue Claim
              </button>
              <button
                onClick={() => setSelectedDonationForSafety(null)}
                className="px-4 bg-gray-100 hover:bg-gray-200 text-gray-600 font-semibold rounded-xl text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. NGO VOLUNTEER ASSIGNMENT DIALOG */}
      {selectedDonationForVolunteer && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full border border-gray-100 shadow-2xl space-y-4 animate-scale-up">
            <div className="text-center">
              <span className="p-3 bg-orange-50 text-orange-600 rounded-full inline-flex mb-2">
                <UserCheck className="h-8 w-8" />
              </span>
              <h3 className="text-base font-extrabold text-gray-900">Dispatch Volunteer Transport</h3>
              <p className="text-xxs text-gray-500">Select an available verification rider to pick up food from {selectedDonationForVolunteer.restaurantName}.</p>
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-semibold text-gray-700">Select Rider</label>
              <select
                value={selectedVolunteerId}
                onChange={(e) => setSelectedVolunteerId(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-gray-200 bg-white text-xs"
              >
                <option value="">-- Choose Rider --</option>
                {volunteers.map(v => (
                  <option key={v.id} value={v.id} disabled={v.status !== 'available'}>
                    {v.name} ({v.status}) - Rating ⭐{v.rating}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex gap-2">
              <button
                onClick={handleVolunteerAssignSubmit}
                disabled={!selectedVolunteerId}
                className={`flex-1 font-bold py-2.5 rounded-xl text-xs text-white ${
                  selectedVolunteerId ? 'bg-green-700 hover:bg-green-800' : 'bg-gray-200 cursor-not-allowed'
                }`}
              >
                Confirm Dispatch
              </button>
              <button
                onClick={() => setSelectedDonationForVolunteer(null)}
                className="px-4 bg-gray-100 hover:bg-gray-200 text-gray-600 font-semibold rounded-xl text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
