import React from 'react';
import { Donation } from '../types';
import { Brain, Flame, Target, Utensils, Award, ShieldCheck, TrendingDown, RefreshCw } from 'lucide-react';

interface AIRecommendationsProps {
  donation: Donation;
  showTitle?: boolean;
}

export const AIRecommendations: React.FC<AIRecommendationsProps> = ({ donation, showTitle = true }) => {
  // Safe helper to determine badge color based on risk
  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'High':
        return 'bg-rose-50 text-rose-700 border border-rose-200';
      case 'Medium':
        return 'bg-amber-50 text-amber-700 border border-amber-200';
      default:
        return 'bg-green-50 text-green-700 border border-green-200';
    }
  };

  // Helper for priority score
  const getPriorityColor = (score: number) => {
    if (score >= 8.5) return 'text-rose-600 bg-rose-50';
    if (score >= 6.0) return 'text-amber-600 bg-amber-50';
    return 'text-green-600 bg-green-50';
  };

  return (
    <div className="bg-gradient-to-br from-green-50/50 to-orange-50/40 border border-green-100 rounded-2xl p-5 shadow-sm" id={`ai-recs-${donation.id}`}>
      {showTitle && (
        <div className="flex items-center gap-2 mb-4 border-b border-green-100 pb-2">
          <div className="bg-green-600 text-white p-1 rounded-lg">
            <Brain className="h-5 w-5" />
          </div>
          <div>
            <h4 className="font-bold text-sm text-gray-800">Akshaya Patra Smart AI Engine</h4>
            <p className="text-xxs text-gray-500">Real-time optimization & predictive intelligence</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3">
        {/* Priority Score Card */}
        <div className="bg-white p-3 rounded-xl border border-gray-100 shadow-xxs">
          <div className="flex items-center gap-1.5 text-gray-500 text-xxs font-medium mb-1">
            <Target className="h-3.5 w-3.5 text-green-600" />
            Priority Score
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className={`text-xl font-black rounded px-1.5 py-0.5 ${getPriorityColor(donation.priorityScore)}`}>
              {donation.priorityScore.toFixed(1)}
            </span>
            <span className="text-xxs text-gray-400">/10.0</span>
          </div>
          <p className="text-xxs text-gray-500 mt-1 leading-tight">
            Based on quantity, distance, and critical expiry.
          </p>
        </div>

        {/* Expiry Risk Card */}
        <div className="bg-white p-3 rounded-xl border border-gray-100 shadow-xxs">
          <div className="flex items-center gap-1.5 text-gray-500 text-xxs font-medium mb-1">
            <Flame className="h-3.5 w-3.5 text-orange-500" />
            Expiry Risk
          </div>
          <div>
            <span className={`inline-block px-2 py-0.5 rounded text-xs font-bold uppercase tracking-wider ${getRiskColor(donation.expiryRisk)}`}>
              {donation.expiryRisk} Risk
            </span>
          </div>
          <p className="text-xxs text-gray-500 mt-1.5 leading-tight">
            Expires in {donation.expiryTime}. Fast pickup recommended.
          </p>
        </div>

        {/* Estimated Meals */}
        <div className="bg-white p-3 rounded-xl border border-gray-100 shadow-xxs">
          <div className="flex items-center gap-1.5 text-gray-500 text-xxs font-medium mb-1">
            <Utensils className="h-3.5 w-3.5 text-blue-500" />
            Estimated Meals
          </div>
          <div className="text-xl font-bold text-gray-800">
            ~{donation.estMealsServed}
          </div>
          <p className="text-xxs text-gray-500 mt-0.5 leading-tight">
            Feeds approximately {Math.round(donation.estMealsServed / 1.5)} people with high nutritional efficiency.
          </p>
        </div>

        {/* Smart NGO Matches */}
        <div className="bg-white p-3 rounded-xl border border-gray-100 shadow-xxs">
          <div className="flex items-center gap-1.5 text-gray-500 text-xxs font-medium mb-1">
            <ShieldCheck className="h-3.5 w-3.5 text-purple-600" />
            AI Matched NGOs
          </div>
          <div className="space-y-1">
            {donation.smartMatches.slice(0, 2).map((ngo, idx) => (
              <div key={idx} className="bg-green-50 text-green-800 text-xxs font-semibold px-1.5 py-0.5 rounded truncate max-w-full">
                🎯 {ngo}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-3 bg-white/70 rounded-xl p-2.5 border border-gray-100 text-xxs text-gray-600 flex items-start gap-1.5">
        <TrendingDown className="h-4 w-4 text-orange-500 mt-0.5 flex-shrink-0" />
        <div>
          <span className="font-semibold text-gray-800">Waste Prevention Analysis:</span> Accept within 45 mins to prevent landfill decomposition and mitigate up to <span className="font-bold text-green-700">{(donation.estMealsServed * 0.45).toFixed(1)} kg</span> of CO₂ emissions.
        </div>
      </div>
    </div>
  );
};

// Subcomponent: AI Predictive Insights Card
export const AIPredictiveTrends: React.FC = () => {
  return (
    <div className="bg-gradient-to-br from-green-900 via-green-800 to-green-950 text-white rounded-2xl p-5 shadow-lg border border-green-700" id="ai-predictive-trends-container">
      <div className="flex items-center justify-between border-b border-green-700 pb-3 mb-4">
        <div className="flex items-center gap-2">
          <Brain className="h-5 w-5 text-orange-400" />
          <div>
            <h4 className="font-bold text-sm">AI Food Waste Predictive Trends</h4>
            <p className="text-xxs text-green-300">Predictive intelligence model v2.1</p>
          </div>
        </div>
        <span className="bg-green-700 text-green-200 text-xxs font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
          <RefreshCw className="h-2.5 w-2.5 animate-spin" /> Active
        </span>
      </div>

      <div className="space-y-3.5">
        <div>
          <div className="flex justify-between text-xs mb-1">
            <span className="text-gray-300">Weekend Surplus Surplus Forecast</span>
            <span className="text-orange-400 font-bold">+28% surplus expected</span>
          </div>
          <p className="text-xxs text-gray-300 leading-relaxed">
            Due to upcoming monsoon wedding banquets on Friday & Saturday. NGO notification dispatches pre-scheduled.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-2.5 pt-1">
          <div className="bg-green-800/40 p-2.5 rounded-xl border border-green-700/60">
            <span className="text-xxs text-gray-300 block">Next Week Target Match</span>
            <span className="text-sm font-bold text-orange-400">99.1% Accuracy</span>
            <span className="text-xxs block text-gray-400 mt-0.5">Optimizing volunteer routes.</span>
          </div>
          <div className="bg-green-800/40 p-2.5 rounded-xl border border-green-700/60">
            <span className="text-xxs text-gray-300 block">Carbon Offset Project</span>
            <span className="text-sm font-bold text-green-300">-2.1 Tonnes CO₂</span>
            <span className="text-xxs block text-gray-400 mt-0.5">Estimated reduction target.</span>
          </div>
        </div>

        <div className="bg-orange-500/10 border border-orange-500/20 text-orange-300 text-xxs p-2 rounded-lg flex items-start gap-1.5">
          <Award className="h-4 w-4 text-orange-400 mt-0.5 flex-shrink-0" />
          <div>
            <span className="font-bold">AI Suggestion:</span> Divert surplus bakery items to Gachibowli sector shelter. Highest demand mismatch identified between 8:00 PM and 10:00 PM.
          </div>
        </div>
      </div>
    </div>
  );
};
