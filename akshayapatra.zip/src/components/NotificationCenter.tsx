import React from 'react';
import { AppNotification } from '../types';
import { Bell, Check, Trash2, Award, Info, AlertTriangle, CheckCircle, Zap } from 'lucide-react';

interface NotificationCenterProps {
  notifications: AppNotification[];
  onMarkRead: (id: string) => void;
  onClearAll: () => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  notifications,
  onMarkRead,
  onClearAll,
}) => {
  const unreadCount = notifications.filter(n => !n.read).length;

  const getIcon = (type: AppNotification['type']) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-amber-500" />;
      case 'achievement':
        return <Award className="h-5 w-5 text-yellow-500" />;
      default:
        return <Info className="h-5 w-5 text-blue-500" />;
    }
  };

  const getBg = (type: AppNotification['type'], read: boolean) => {
    if (read) return 'bg-white opacity-80';
    switch (type) {
      case 'success':
        return 'bg-green-50 border-l-4 border-green-600';
      case 'warning':
        return 'bg-amber-50 border-l-4 border-amber-50';
      case 'achievement':
        return 'bg-yellow-50 border-l-4 border-yellow-500';
      default:
        return 'bg-blue-50 border-l-4 border-blue-500';
    }
  };

  return (
    <div className="w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100" id="notification-center-container">
      <div className="p-4 bg-gradient-to-r from-green-700 to-green-600 text-white flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Bell className="h-5 w-5 animate-bounce" />
          <h3 className="font-semibold text-lg">Live Notifications</h3>
          {unreadCount > 0 && (
            <span className="bg-orange-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
              {unreadCount} New
            </span>
          )}
        </div>
        {notifications.length > 0 && (
          <button 
            onClick={onClearAll}
            className="text-xs hover:underline flex items-center gap-1 opacity-90 hover:opacity-100 transition"
            title="Clear all"
          >
            <Trash2 className="h-3.5 w-3.5" /> Clear
          </button>
        )}
      </div>

      <div className="max-h-96 overflow-y-auto divide-y divide-gray-100">
        {notifications.length === 0 ? (
          <div className="p-8 text-center text-gray-400">
            <Bell className="h-10 w-10 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No notifications yet.</p>
          </div>
        ) : (
          notifications.map((notification) => (
            <div 
              key={notification.id}
              className={`p-4 transition duration-200 hover:bg-gray-50 flex gap-3 ${getBg(notification.type, notification.read)}`}
            >
              <div className="mt-0.5 flex-shrink-0">
                {getIcon(notification.type)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-baseline gap-2">
                  <p className={`text-sm font-semibold text-gray-900 ${!notification.read ? 'font-bold' : ''}`}>
                    {notification.title}
                  </p>
                  <span className="text-xxs text-gray-400 whitespace-nowrap">{notification.timestamp}</span>
                </div>
                <p className="text-xs text-gray-600 mt-1 leading-relaxed">
                  {notification.message}
                </p>
                {!notification.read && (
                  <button 
                    onClick={() => onMarkRead(notification.id)}
                    className="mt-2 text-xxs font-medium text-green-700 hover:text-green-800 flex items-center gap-0.5 hover:underline"
                  >
                    <Check className="h-3 w-3" /> Mark as read
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
      <div className="p-3 bg-gray-50 border-t border-gray-100 text-center">
        <p className="text-xxs text-gray-500 flex items-center justify-center gap-1">
          <Zap className="h-3 w-3 text-orange-500" /> Powered by Akshaya Patra Firebase sync
        </p>
      </div>
    </div>
  );
};
