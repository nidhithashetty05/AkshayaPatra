export type UserRole = 'donor' | 'ngo' | 'volunteer' | 'admin';

export type DonationStatus = 'pending' | 'accepted' | 'assigned' | 'picked_up' | 'delivered' | 'cancelled';

export interface Donation {
  id: string;
  foodName: string;
  category: string;
  vegNonVeg: 'Veg' | 'Non-Veg';
  quantity: string;
  prepTime: string;
  expiryTime: string;
  pickupAddress: string;
  location: string;
  imageUrl?: string;
  condition: string;
  specialInstructions: string;
  status: DonationStatus;
  createdAt: string;
  restaurantName: string;
  ngoName: string | null;
  volunteerName: string | null;
  volunteerPhone: string | null;
  assignedAt: string | null;
  pickedUpAt: string | null;
  deliveredAt: string | null;
  distanceKm: number;
  priorityScore: number; // AI Field
  expiryRisk: 'Low' | 'Medium' | 'High'; // AI Field
  estMealsServed: number; // AI Field
  smartMatches: string[]; // AI Field
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type: 'info' | 'success' | 'warning' | 'achievement';
}

export interface LeaderboardItem {
  restaurantName: string;
  totalDonatedKg: number;
  mealsDonated: number;
  tier: 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
  badge: string;
}

export interface Volunteer {
  id: string;
  name: string;
  phone: string;
  status: 'available' | 'busy' | 'offline';
  completedDeliveries: number;
  rating: number;
  currentLocation: string;
}

export interface AppState {
  donations: Donation[];
  notifications: AppNotification[];
  volunteers: Volunteer[];
  leaderboard: LeaderboardItem[];
  currentUser: {
    name: string;
    role: UserRole;
    email: string;
    orgName: string;
    phone: string;
  } | null;
}
